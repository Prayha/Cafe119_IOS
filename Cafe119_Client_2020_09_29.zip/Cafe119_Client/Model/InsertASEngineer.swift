//
//  InsertASEngineer.swift
//  Cafe119_Customer
//
//  Created by TJ on 2020/09/22.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation

class InsertASEngineer: NSObject {
        
    func insertItems(cSeqno: String, eSeqno: String) -> Bool { // 2

        var urlPath = URLPATH + "Insert_AS_Engineer.jsp"
        
        var result: Bool = true
        let urlAdd = "?cSeqno=\(cSeqno)&eSeqno=\(eSeqno)" // urlPath 뒤에 입력할 내용을 추가하기위해 만든 변수
        urlPath = urlPath + urlAdd
        print(urlPath)
        
        // 한글 url encoding
        urlPath = urlPath.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        
        let url: URL = URL(string: urlPath)!
        let defaultSession = Foundation.URLSession(configuration: URLSessionConfiguration.default)
        
        let task = defaultSession.dataTask(with: url) {(data, response, error) in
            if error != nil {
                print("Failed to Insert Data : \(String(describing: error))")
                result = false
            } else {
                print("Data is Inserted")
                
                result = true
            }
        }
        
        task.resume()
        
        return result
    }
}
