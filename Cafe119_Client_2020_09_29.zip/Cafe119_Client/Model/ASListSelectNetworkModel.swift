//
//  SelectNetwork.swift
//  Cafe119_Client
//
//  Created by TJ on 2020/09/24.
//  Copyright © 2020 Cafe119. All rights reserved.
//

import Foundation


protocol ASListSelectNetworkModelProtocol: class {
    func itemDownloaded(ASList: ASListStruct)
}

class ASListSelectNetworkModel: NSObject {
    
    var delegate: ASListSelectNetworkModelProtocol!
    
    func downloadItems(urlPath: String) { // 2
        let url: URL = URL(string: urlPath)!
        print(urlPath)
        let defaultSession = Foundation.URLSession(configuration: URLSessionConfiguration.default)
        
        let task = defaultSession.dataTask(with: url) {(data, response, error) in
            if error != nil {
                print("Failed to download Data : \(String(describing: error))")
            } else {
                print("Data is downloaded ASListSelectNetworkModel")
                
                self.parseJson(data!)
            }
        }
        
        task.resume()
    }
    
    func parseJson(_ data: Data) {
        let jsonDecoder = JSONDecoder()
        
        // json 파싱
        if let ASList = try? jsonDecoder.decode(ASListStruct.self, from: data) {
            print(ASList)
            DispatchQueue.main.async(execute: {() -> Void in
                self.delegate.itemDownloaded(ASList: ASList)
            })
        }
    }
}
