//
//  ASList.swift
//  Cafe119_Client
//
//  Created by TJ on 2020/09/24.
//  Copyright © 2020 Cafe119. All rights reserved.
//

import Foundation

struct ASListStruct : Codable {
    var aslSeqno: String
    var aslStatus: String
    var Engineer_eSeqno: String
    var eName: String
}

class ASList {
    var aslSeqno: String?
    var aslType: String?
    var aslContent: String?
    var aslImagePath: String?
    var aslDate: String?
    var aslStatus: String?
    var Client_cSeqno: String?
    var Engineer_eSeqno: String?
    
    init() {
        
    }
    
    init(aslStatus: String) {
        self.aslStatus = aslStatus
    }
    
    init(aslSeqno: String, aslType: String, aslContent: String, aslImagePath: String, aslDate: String, aslStatus: String, Client_cSeqno: String, Engineer_eSeqno: String) {
        self.aslSeqno = aslSeqno
        self.aslType = aslType
        self.aslContent = aslContent
        self.aslImagePath = aslImagePath
        self.aslDate = aslDate
        self.aslStatus = aslStatus
        self.Client_cSeqno = Client_cSeqno
        self.Engineer_eSeqno = Engineer_eSeqno
    }
}
