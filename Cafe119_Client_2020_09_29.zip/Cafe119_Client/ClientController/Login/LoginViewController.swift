//
//  LoginViewController.swift
//  Cafe119
//
//  Created by TJ on 2020/09/16.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit

let URLPATH = "http://localhost:8080/Cafe119/"
var USERDATA: ClientLoginUpDBModel2?
var ENGINEERDATA: EngineerSignUpDBModel2?

class LoginViewController: UIViewController, ClientLoginModelProtocol {
    
    var userId:String?
    var userPassword:String?
    var uSeqno:String = ""
    //    var feedItem: NSArray = NSArray()
    
    @IBOutlet weak var tfId: UITextField!
    @IBOutlet weak var tfPassword: UITextField!
    @IBOutlet weak var btnRegister: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        let idPaddingView: UIView = UIView(frame: CGRect(x: 0, y: 0, width: 5, height: 20))
        tfId.leftView = idPaddingView
        tfId.leftViewMode = .always
        let passwordPaddingView: UIView = UIView(frame: CGRect(x: 0, y: 0, width: 5, height: 20))
        tfPassword.leftView = passwordPaddingView
        tfPassword.leftViewMode = .always
        
        print("login page")
    }
    
    // 손님버튼
    @IBAction func btnClient(_ sender: UIButton) {
        ClientloginAction()
    }
    
    func ClientloginAction() {
        
        self.userId = tfId.text!
        self.userPassword = tfPassword.text!
        if(self.userId == nil || self.userId == ""){
            myAlert(alertTitle: "오류", alertMessage: "아이디를 입력해주세요.", actionTitle: "OK", handler: nil)
            
        } else if self.userPassword == nil {
            myAlert(alertTitle: "오류", alertMessage: "비밀번호를 입력해주세요.", actionTitle: "OK", handler: nil)
            
        } else { // 로그인성공
            let queryModel = ClientLoginModel()
            queryModel.delegate = self
            queryModel.ClientloadItems(cId: userId!)
            
        }
    }
    
    func ClientLoginChkDwonloaded(item: String) {
        self.userId = tfId.text!
        self.userPassword = tfPassword.text!
        if USERDATA?.cId != userId {
            myAlert(alertTitle: "오류", alertMessage: "등록되지 않은 정보입니다.", actionTitle: "OK", handler: nil)
        } else if USERDATA?.cPw != userPassword {
            myAlert(alertTitle: "오류", alertMessage: "비밀번호가 일치 하지않습니다.", actionTitle: "OK", handler: nil)
        } else {
            self.performSegue(withIdentifier: "sgClient", sender: nil)
        }
    }
    
    func myAlert(alertTitle: String, alertMessage: String, actionTitle: String, handler:((UIAlertAction) -> Void)?) {
        let resultAlert = UIAlertController(title: alertTitle, message: alertMessage, preferredStyle: UIAlertController.Style.alert)
        let onAction = UIAlertAction(title: actionTitle, style: UIAlertAction.Style.default, handler: handler)
        resultAlert.addAction(onAction)
        present(resultAlert, animated: true, completion: nil)
    }
}
