//
//  ASSearchTableViewCell.swift
//  Cafe119
//
//  Created by taeheum on 2020/09/18.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit

class ASSearchTableViewCell: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblTelno: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblContent: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblScore: UILabel!
    

}
