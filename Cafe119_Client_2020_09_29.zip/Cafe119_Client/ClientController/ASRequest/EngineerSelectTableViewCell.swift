//
//  EngineerSelectTableViewCell.swift
//  Cafe119_Customer
//
//  Created by TJ on 2020/09/22.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit

class EngineerSelectTableViewCell: UITableViewCell {
    
    @IBOutlet var lblEngineerName: UILabel!
    @IBOutlet var lblPhone: UILabel!
    @IBOutlet var lblPrice: UILabel!
    @IBOutlet var lblTime: UILabel!
}
