//
//  CustomerASReviewViewController.swift
//  Cafe119
//
//  Created by TJ on 2020/09/16.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit

class CustomerASReviewDatailViewController: UIViewController {
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblScore: UILabel!
    @IBOutlet weak var tvContent: UITextView!
    var receiveName = ""
    var receiveScore = ""
    var receiveContent = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        lblName.text = receiveName
        lblScore.text = (receiveScore + " / 5.0")
        tvContent.text = receiveContent
    }
    
    func receiveItems(_ name:String, _ score:String, _ content:String) {
        receiveName = name
        receiveScore = score
        receiveContent = content
    }
}
