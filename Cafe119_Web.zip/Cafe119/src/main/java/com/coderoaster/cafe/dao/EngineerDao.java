package com.coderoaster.cafe.dao;

import java.util.ArrayList;

import com.coderoaster.cafe.dto.EngineerDTO;

public interface EngineerDao {

	public ArrayList<EngineerDTO> EngineerAllSelect();
	
	public void EngineerDelete(String eSeqno);
	
	public EngineerDTO EngineerUpdateInfo(String eSeqno);
	public void EngineerUpdateGo(String eId, String ePw, String eName, String eEmail, String eImage, 
								String eTelno, String eDate, String eBusinessNumber, String eAddress, String eSeqno);
}
