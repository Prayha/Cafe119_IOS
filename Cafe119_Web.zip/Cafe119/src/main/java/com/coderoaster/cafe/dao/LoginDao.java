package com.coderoaster.cafe.dao;

public interface LoginDao  {

	public void signUpDao(String aId, String aPw);
	
	public int logingCheck(String aId, String aPw);
}
