package com.coderoaster.cafe;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.coderoaster.cafe.dao.ClientDao;
import com.coderoaster.cafe.dto.ClientDTO;

@Controller
public class ClientController {

	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping("/Client")
	public String Member(Model model, HttpServletRequest request) {
		
		ClientDao memberDao = sqlSession.getMapper(ClientDao.class);
		ArrayList<ClientDTO> data = memberDao.ClientAllSelect();
		
		model.addAttribute("data", data);
		
		return "Client";
	}
	
	@RequestMapping("/ClientDelete")
	public String ClientDelete(Model model, HttpServletRequest request) {

		String cSeqno = (String) request.getParameter("cSeqno");
				
		ClientDao memberDao = sqlSession.getMapper(ClientDao.class);
		memberDao.ClientDelete(cSeqno);
		
		return "redirect:Client";
	}
	
	@RequestMapping("/ClientUpdate")
	public String ClientUpdate(Model model, HttpServletRequest request) {

		String cSeqno = (String) request.getParameter("cSeqno");
		
		ClientDao memberDao = sqlSession.getMapper(ClientDao.class);
		ClientDTO data = memberDao.ClientUpdateInfo(cSeqno);
		
		model.addAttribute("data", data);
		
		return "ClientUpdate";
	}
	
	@RequestMapping("/UpdateClientGo")
	public String UpdateClientGo(Model model, HttpServletRequest request) {
		
		String cSeqno = (String) request.getParameter("cSeqno");
		String cId = (String) request.getParameter("cId");
		String cPw = (String) request.getParameter("cPw");
		String cName = (String) request.getParameter("cName");
		String cEmail = (String) request.getParameter("cEmail");
		String cImage = (String) request.getParameter("cImage");
		String cTelno = (String) request.getParameter("cTelno");
		String cDate = (String) request.getParameter("cDate");
		String cBusinessNumber = (String) request.getParameter("cBusinessNumber");
		String cRegion = (String) request.getParameter("cRegion");
		String cLongitude = (String) request.getParameter("cLongitude");
		String cLatitude = (String) request.getParameter("cLatitude");
		
		
		ClientDao memberDao = sqlSession.getMapper(ClientDao.class);
		memberDao.ClientUpdateGo(cId, cPw, cName, cEmail, cImage, cTelno, cDate, cBusinessNumber, cRegion, cLongitude, cLatitude, cSeqno);
		
		return "redirect:Client";
	}
}
