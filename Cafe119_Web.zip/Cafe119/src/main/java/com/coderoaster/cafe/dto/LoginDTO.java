package com.coderoaster.cafe.dto;

public class LoginDTO {

	private int aSeqno;
	private String aId;
	private String aPw;
		
	public LoginDTO() {
		super();
	}

	public LoginDTO(int aSeqno, String aId, String aPw) {
		super();
		this.aSeqno = aSeqno;
		this.aId = aId;
		this.aPw = aPw;
	}

	public int getaSeqno() {
		return aSeqno;
	}

	public void setaSeqno(int aSeqno) {
		this.aSeqno = aSeqno;
	}

	public String getaId() {
		return aId;
	}

	public void setaId(String aId) {
		this.aId = aId;
	}

	public String getaPw() {
		return aPw;
	}

	public void setaPw(String aPw) {
		this.aPw = aPw;
	}		
}
