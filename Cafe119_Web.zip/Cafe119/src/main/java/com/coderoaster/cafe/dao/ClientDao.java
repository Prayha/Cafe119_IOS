package com.coderoaster.cafe.dao;

import java.util.ArrayList;

import com.coderoaster.cafe.dto.ClientDTO;

public interface ClientDao {

	public ArrayList<ClientDTO> ClientAllSelect();
	
	public void ClientDelete(String cSeqno);
	
	public ClientDTO ClientUpdateInfo(String cSeqno);
	public void ClientUpdateGo(String cId, String cPw, String cName, String cEmail, String cImage, 
								String cTelno, String cDate, String cBusinessNumber, String cRegion, String cLongitude, String cLatitude, String cSeqno);
}
