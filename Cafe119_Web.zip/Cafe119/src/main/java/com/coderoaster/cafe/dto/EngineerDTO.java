package com.coderoaster.cafe.dto;

public class EngineerDTO {

	private int eSeqno;
	private String eId;
	private String ePw;
	private String eName;
	private String eEmail;
	private String eImage;
	private String eTelno;
	private String eBusinessNumber;
	private String eDate;
	private String eAddress;
	
	public EngineerDTO() {
		super();
	}

	public EngineerDTO(int eSeqno, String eId, String ePw, String eName, String eEmail, String eImage, String eTelno,
			String eBusinessNumber, String eDate, String eAddress) {
		super();
		this.eSeqno = eSeqno;
		this.eId = eId;
		this.ePw = ePw;
		this.eName = eName;
		this.eEmail = eEmail;
		this.eImage = eImage;
		this.eTelno = eTelno;
		this.eBusinessNumber = eBusinessNumber;
		this.eDate = eDate;
		this.eAddress = eAddress;
	}

	public int geteSeqno() {
		return eSeqno;
	}

	public void seteSeqno(int eSeqno) {
		this.eSeqno = eSeqno;
	}

	public String geteId() {
		return eId;
	}

	public void seteId(String eId) {
		this.eId = eId;
	}

	public String getePw() {
		return ePw;
	}

	public void setePw(String ePw) {
		this.ePw = ePw;
	}

	public String geteName() {
		return eName;
	}

	public void seteName(String eName) {
		this.eName = eName;
	}

	public String geteEmail() {
		return eEmail;
	}

	public void seteEmail(String eEmail) {
		this.eEmail = eEmail;
	}

	public String geteImage() {
		return eImage;
	}

	public void seteImage(String eImage) {
		this.eImage = eImage;
	}

	public String geteTelno() {
		return eTelno;
	}

	public void seteTelno(String eTelno) {
		this.eTelno = eTelno;
	}

	public String geteBusinessNumber() {
		return eBusinessNumber;
	}

	public void seteBusinessNumber(String eBusinessNumber) {
		this.eBusinessNumber = eBusinessNumber;
	}

	public String geteDate() {
		return eDate;
	}

	public void seteDate(String eDate) {
		this.eDate = eDate;
	}

	public String geteAddress() {
		return eAddress;
	}

	public void seteAddress(String eAddress) {
		this.eAddress = eAddress;
	}	
}
