package com.coderoaster.cafe;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.coderoaster.cafe.dao.ClientDao;
import com.coderoaster.cafe.dao.EngineerDao;
import com.coderoaster.cafe.dto.ClientDTO;
import com.coderoaster.cafe.dto.EngineerDTO;

@Controller
public class EngineerController {

	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping("/Engineer")
	public String Engineer(Model model, HttpServletRequest request) {
		
		EngineerDao engineerDao = sqlSession.getMapper(EngineerDao.class);
		ArrayList<EngineerDTO> data = engineerDao.EngineerAllSelect();
		
		model.addAttribute("data", data);
		
		return "Engineer";
	}
	
	@RequestMapping("/EngineerDelete")
	public String EngineerDelete(Model model, HttpServletRequest request) {

		String eSeqno = (String) request.getParameter("eSeqno");
		
		EngineerDao engineerDao = sqlSession.getMapper(EngineerDao.class);
		engineerDao.EngineerDelete(eSeqno);
		
		return "redirect:Engineer";
	}
	
	@RequestMapping("/EngineerUpdate")
	public String EngineerUpdate(Model model, HttpServletRequest request) {

		String eSeqno = (String) request.getParameter("eSeqno");	

		EngineerDao engineerDao = sqlSession.getMapper(EngineerDao.class);
		EngineerDTO data = engineerDao.EngineerUpdateInfo(eSeqno);
		
		model.addAttribute("data", data);
		
		return "EngineerUpdate";
	}
	
	@RequestMapping("/UpdateEngineerGo")
	public String UpdateEngineerGo(Model model, HttpServletRequest request) {
		
		String eSeqno = (String) request.getParameter("eSeqno");
		String eId = (String) request.getParameter("eId");
		String ePw = (String) request.getParameter("ePw");
		String eName = (String) request.getParameter("eName");
		String eEmail = (String) request.getParameter("eEmail");
		String eImage = (String) request.getParameter("eImage");
		String eTelno = (String) request.getParameter("eTelno");
		String eDate = (String) request.getParameter("eDate");
		String eBusinessNumber = (String) request.getParameter("eBusinessNumber");
		String eAddress = (String) request.getParameter("eAddress");

		EngineerDao engineerDao = sqlSession.getMapper(EngineerDao.class);
		engineerDao.EngineerUpdateGo(eId, ePw, eName, eEmail, eImage, eTelno, eDate, eBusinessNumber, eAddress, eSeqno);
		
		return "redirect:Engineer";
	}
}
