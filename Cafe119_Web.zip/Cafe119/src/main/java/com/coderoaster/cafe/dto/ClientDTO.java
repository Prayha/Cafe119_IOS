package com.coderoaster.cafe.dto;

import java.sql.Date;

public class ClientDTO {
 
	private int cSeqno;
	private String cId;
	private String cPw;
	private String cName;
	private String cEmail;
	private String cImage;
	private String cTelno;
	private String cBusinessNumber;
	private Date cDate;
	private String cRegion;
	private Double cLongitude;
	private Double cLatitude;
	
	public ClientDTO() {
		super();
	}

	public ClientDTO(int cSeqno, String cId, String cPw, String cName, String cEmail, String cImage, String cTelno,
			String cBusinessNumber, Date cDate, String cRegion, Double cLongitude, Double cLatitude) {
		super();
		this.cSeqno = cSeqno;
		this.cId = cId;
		this.cPw = cPw;
		this.cName = cName;
		this.cEmail = cEmail;
		this.cImage = cImage;
		this.cTelno = cTelno;
		this.cBusinessNumber = cBusinessNumber;
		this.cDate = cDate;
		this.cRegion = cRegion;
		this.cLongitude = cLongitude;
		this.cLatitude = cLatitude;
	}

	public int getcSeqno() {
		return cSeqno;
	}

	public void setcSeqno(int cSeqno) {
		this.cSeqno = cSeqno;
	}

	public String getcId() {
		return cId;
	}

	public void setcId(String cId) {
		this.cId = cId;
	}

	public String getcPw() {
		return cPw;
	}

	public void setcPw(String cPw) {
		this.cPw = cPw;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public String getcEmail() {
		return cEmail;
	}

	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}

	public String getcImage() {
		return cImage;
	}

	public void setcImage(String cImage) {
		this.cImage = cImage;
	}

	public String getcTelno() {
		return cTelno;
	}

	public void setcTelno(String cTelno) {
		this.cTelno = cTelno;
	}

	public String getcBusinessNumber() {
		return cBusinessNumber;
	}

	public void setcBusinessNumber(String cBusinessNumber) {
		this.cBusinessNumber = cBusinessNumber;
	}

	public Date getcDate() {
		return cDate;
	}

	public void setcDate(Date cDate) {
		this.cDate = cDate;
	}

	public String getcRegion() {
		return cRegion;
	}

	public void setcRegion(String cRegion) {
		this.cRegion = cRegion;
	}

	public Double getcLongitude() {
		return cLongitude;
	}

	public void setcLongitude(Double cLongitude) {
		this.cLongitude = cLongitude;
	}

	public Double getcLatitude() {
		return cLatitude;
	}

	public void setcLatitude(Double cLatitude) {
		this.cLatitude = cLatitude;
	}	
}
