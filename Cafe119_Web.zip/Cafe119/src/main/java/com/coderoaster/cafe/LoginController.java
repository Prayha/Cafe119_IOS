package com.coderoaster.cafe;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.coderoaster.cafe.dao.LoginDao;

@Controller
public class LoginController {
	
	@Autowired
	private SqlSession sqlSession;
	
	// PageMove
	@RequestMapping("/Login")
	public String Login(Model model) {
		
		return "Login";
	}
	
	@RequestMapping("/LoginCheck")
	public String LoginCheck(Model model, HttpServletRequest request) {
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");

		// Login Check
		LoginDao loginDao = sqlSession.getMapper(LoginDao.class);
		int check = loginDao.logingCheck(id, pw);
		
		// Login Success
		if (check == 1) {
			System.out.println("id = " + id);
			HttpSession session = request.getSession();
			session.setAttribute("Id", id);
			
			return "redirect:Client";
		}
		
		return "Login";
	}
	
	// PageMove
	@RequestMapping("/SignUp")
	public String SignUp(Model model, HttpServletRequest request) {
		
		return "SignUp";
	}
		
	@RequestMapping("/DBSignUp")
	public String DBSignUp(Model model, HttpServletRequest request) {
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		// SignUp
		LoginDao loginDao = sqlSession.getMapper(LoginDao.class);
		loginDao.signUpDao(id, pw);
		
		return "Login";
	}
}
