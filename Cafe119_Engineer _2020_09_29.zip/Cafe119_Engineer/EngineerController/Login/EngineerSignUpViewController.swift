//
//  EngineerSignUpViewController.swift
//  Cafe119
//
//  Created by TJ on 2020/09/16.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit

class EngineerSignUpViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate, IdChkModelProtocol {
    
    @IBOutlet weak var btnImage: UIButton!
    @IBOutlet weak var tfId: UITextField!
    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var tfPw: UITextField!
    @IBOutlet weak var tfPwChk: UITextField!
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfPhone: UITextField!
    @IBOutlet weak var tfAddress: UITextField!
    @IBOutlet weak var tfBusinessRegistration: UITextField! // 사업자 등록증
    
    let imagePickerController = UIImagePickerController()
    
    var imageURL: URL?
    
    var IdCheckResult: Int = 2
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        imagePickerController.delegate = self
        
        tfName.isEnabled = false
        tfPw.isEnabled = false
        tfPw.isEnabled = false
        tfPwChk.isEnabled = false
        tfEmail.isEnabled = false
        tfAddress.isEnabled = false
        tfBusinessRegistration.isEnabled = false
        tfPhone.isEnabled = false
    }
    
    @IBAction func btnPhoto(_ sender: UIButton) {
        // 앨범 호출
        imagePickerController.sourceType = .photoLibrary
        self.present(imagePickerController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            
            btnImage.setImage(image, for: UIControl.State.normal)
            
            imageURL = info[UIImagePickerController.InfoKey.imageURL] as? URL
            
        }
        
        // 켜놓은 앨범 화면 없애기
        dismiss(animated: true, completion: nil)
    }
    
    
    // 가입하기 버튼
    @IBAction func btnSignUp(_ sender: UIButton) {
        
        let Id = tfId.text!.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: " ", with: "")
        let Name = tfName.text!.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: " ", with: "")
        let Password = tfPw.text!.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: " ", with: "")
        let chkPassword = tfPwChk.text!.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: " ", with: "")
        let Email = tfEmail.text!.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: " ", with: "")
        let Phone = tfPhone!.text!.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: " ", with: "")
        let Address = tfAddress!.text!.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: " ", with: "")
        let BusinessRegistration = tfBusinessRegistration!.text!.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: " ", with: "")
        
        let parameters = [
            "Id" : Id,
            "Name" : Name,
            "Password" : Password,
            "Email" : Email,
            "Phone" : Phone,
            "Address" : Address,
            "BusinessRegistration" : BusinessRegistration
        ]
        
        
        
        
        Check(Password, Name, chkPassword, Id, Phone, Address, BusinessRegistration, Email)
        
        if validatePassword(password: Password){
            
        }else{
            myAlert(alertTitle: "실패", alertMessage: "최소 8글자이상, 대문자, 소문자, 숫자 조합으로 입력해주새요.", actionTitle: "OK", handler: nil)
            
        }
        
        if tfPwChk.text == tfPw.text{
            let resultAlert = UIAlertController(title: "완료", message: "회원가입에 성공했습니다.", preferredStyle: UIAlertController.Style.alert)
            let  onAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: {Action in
                // 전화면으로 넘어가기위한것
                self.navigationController?.popViewController(animated: true)
                
                let singupModel = EngineerSignUpModel()
                
                
                singupModel.uploadImageFile(at: self.imageURL!, parameters: parameters, completionHandler: {_,_ in})
                
            })
            resultAlert.addAction(onAction)
            present(resultAlert, animated: true, completion: nil)
            
            
            
        } else {
            let resultAlert = UIAlertController(title: "실패", message: "비밀번호가 일치하지 않습니다.", preferredStyle: UIAlertController.Style.alert)
            let  onAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
            resultAlert.addAction(onAction)
            present(resultAlert, animated: true, completion: nil)
        }
    }
    
    // 중복확인 버튼
    @IBAction func btnDoubleCheck(_ sender: UIButton) {
        let Id = tfId.text!
        
        let Idchk = IdChkModel()
        Idchk.delegate = self
        Idchk.IdChkloadItems(eId: Id)
        
    }
    
    func itemDownloaded(item: Int) {
        IdCheckResult = item
        
        if IdCheckResult == 0 {
            //            print("IdCheckResult \(IdCheckResult)")
            myAlert(alertTitle: "확인", alertMessage: "사용가능한 아이디입니다.", actionTitle: "OK", handler: nil)
            tfName.isEnabled = true
            tfPw.isEnabled = true
            tfPw.isEnabled = true
            tfPwChk.isEnabled = true
            tfEmail.isEnabled = true
            tfAddress.isEnabled = true
            tfBusinessRegistration.isEnabled = true
            tfPhone.isEnabled = true
        } else {
            //            print("IdCheckResult \(IdCheckResult)")
            myAlert(alertTitle: "아이디 중복", alertMessage: "이미 사용중인 아이디입니다.", actionTitle: "OK", handler: nil)
        }
    }
    
    
    
    //    password, chkpassword, Id, Phone, Address, BusinessRegistration
    func Check(_ Password:String, _ Name:String, _ chkPassword:String, _ Id:String, _ Phone:String, _ Address:String, _ BusinessRegistration:String, _ Email:String){
        if IdCheckResult == 2{
            myAlert(alertTitle: "실패", alertMessage: "아이디 중복확인을 해주세요", actionTitle: "OK", handler: nil)
        } else if Id.isEmpty {
            myAlert(alertTitle: "실패", alertMessage: "아이디를 입력해주세요", actionTitle: "OK", handler: nil)
        } else if Name.isEmpty {
            myAlert(alertTitle: "실패", alertMessage: "이름을 입력해주세요", actionTitle: "OK", handler: nil)
        } else if Password.isEmpty {
            myAlert(alertTitle: "실패", alertMessage: "비밀번호를 입력해주세요", actionTitle: "OK", handler: nil)
        } else if Email.isEmpty {
            myAlert(alertTitle: "실패", alertMessage: "이메일을 입력해주세요.", actionTitle: "OK", handler: nil)
        } else if !isValidEmail(emailStr: Email) {
            myAlert(alertTitle: "실패", alertMessage: "이메일 형식으로 입력해주세요.", actionTitle: "OK", handler: nil)
        } else if Phone.isEmpty {
            myAlert(alertTitle: "실패", alertMessage: "전화번호를 입력해주세요.", actionTitle: "OK", handler: nil)
        } else if !isPhone(candidate: Phone){
            myAlert(alertTitle: "실패", alertMessage: "전화번호는 숫자만 입력해주세요", actionTitle: "OK", handler: nil)
        } else if Address.isEmpty {
            myAlert(alertTitle: "실패", alertMessage: "주소를 입력해주세요.", actionTitle: "OK", handler: nil)
        } else if BusinessRegistration.isEmpty {
            myAlert(alertTitle: "실패", alertMessage: "사업자 등록증을 입력해주세요.", actionTitle: "OK", handler: nil)
        } else if imageURL == nil {
            myAlert(alertTitle: "실패", alertMessage: "사진을 등록해주세요.", actionTitle: "OK", handler: nil)
        } else {
            
        }
        
        
        
    }
    
    
    func myAlert(alertTitle: String, alertMessage: String, actionTitle: String, handler:((UIAlertAction) -> Void)?) {
        let resultAlert = UIAlertController(title: alertTitle, message: alertMessage, preferredStyle: UIAlertController.Style.alert)
        let onAction = UIAlertAction(title: actionTitle, style: UIAlertAction.Style.default, handler: handler)
        resultAlert.addAction(onAction)
        present(resultAlert, animated: true, completion: nil)
    }
    
    // 이메일
    func isValidEmail(emailStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: emailStr)
    }
    
    
    
    // 패스워드
    func validatePassword(password:String) -> Bool {
        let passwordRegEx = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z]).{8,24}$"
        
        let predicate = NSPredicate(format:"SELF MATCHES %@", passwordRegEx)
        return predicate.evaluate(with: password)
    }
    // 전화번호
    func isPhone(candidate: String) -> Bool {
        
        let regex = "^01([0|1|6|7|8|9]?)([0-9]{3,4})([0-9]{4})$"
        return NSPredicate(format: "SELF MATCHES %@", regex).evaluate(with: candidate)
        
    }
    
    
    
}
