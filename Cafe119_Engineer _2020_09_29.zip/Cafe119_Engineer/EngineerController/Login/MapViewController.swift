//
//  MapViewController.swift
//  Cafe119_Engineer
//
//  Created by Kim_MAC on 2020/09/21.
//  Copyright © 2020 Cafe119. All rights reserved.
//

import UIKit
import WebKit //---------
import CoreLocation
class MapViewController: UIViewController, WKNavigationDelegate, CLLocationManagerDelegate {
    
    
    @IBOutlet weak var myWebView: WKWebView!
    func loadWebPage(url: String){
        let myUrl = URL(string: url)
        let myRequest = URLRequest(url: myUrl!)
        myWebView.load(myRequest)
    }
    var locationManager : CLLocationManager!
    var slatitude = ""
    var slongitude = ""
    //위도와 경도
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization() //권한 요청
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.startUpdatingLocation()
        
        slatitude = SLATITUDE!
        slongitude = SLONGTITUDE!

        

        
        // Do any additional setup after loading the view.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
         //위치가 업데이트될때마다
         if let coor = manager.location?.coordinate{
            print("http://localhost:8080/test/kakaomaptest.jsp?Latitude="+String(coor.latitude)+"&Longitude="+String(coor.longitude)+"&sLatitude="+slatitude+"&sLongitude="+slongitude)
            loadWebPage(url: "http://localhost:8080/test/kakaomaptest.jsp?Latitude="+String(coor.latitude)+"&Longitude="+String(coor.longitude)+"&sLatitude="+slatitude+"&sLongitude="+slongitude)
         }
     }

  

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}

