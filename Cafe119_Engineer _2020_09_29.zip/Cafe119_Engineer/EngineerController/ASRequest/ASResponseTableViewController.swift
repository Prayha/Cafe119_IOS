//
//  ASResponseTableViewController.swift
//  Cafe119_Engineer
//
//  Created by TJ on 2020/09/21.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit

class ASResponseTableViewController: UITableViewController, QueryASListProtocol {
    
    @IBOutlet var asListTableView: UITableView!
    
    var feedItem : NSArray = NSArray()
    var index = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.asListTableView.delegate = self
        self.asListTableView.dataSource = self
        asListTableView.rowHeight = 130
        
        let queryASList = QueryASList()
        queryASList.delegate = self
        queryASList.downloadItems()
        
        // 백버튼 지우기
        self.tabBarController?.navigationItem.setHidesBackButton(true, animated: true)
    }
    
    func itemDownloaded(items: NSArray, index: Int) {
        feedItem = items
        asListTableView.reloadData()
        self.index = index
    }
    
    override func viewWillAppear(_ animated: Bool) {
        let queryASList = QueryASList()
        queryASList.delegate = self
        queryASList.downloadItems()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return feedItem.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as! ASResponseTableViewCell
        
        let item: ASListResponse = feedItem[indexPath.row] as! ASListResponse
        
        if indexPath.row < index {
            cell.lblShopName.text = item.shopName
            cell.lblPhone.text = item.phone
            cell.lblASLType.text = item.aslType
            cell.lblShopAddress.text = item.shopAddress
            cell.backgroundColor = UIColor.cyan
        } else {
            cell.lblShopName.text = item.shopName
            cell.lblPhone.text = item.phone
            cell.lblASLType.text = item.aslType
            cell.lblShopAddress.text = item.shopAddress
            
        }
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130.0
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let item: ASListResponse = feedItem[indexPath.row] as! ASListResponse
        
        if indexPath.row < index {
            let pushVC = self.storyboard?.instantiateViewController(withIdentifier: "Chating") as! ChatViewController
            pushVC.receiveItem(item: item.Client_cSeqno!, aslSeqno: item.aslSeqno!, name: item.shopName!)
            self.navigationController?.pushViewController(pushVC, animated: true)
        } else {
            let pushVC = self.storyboard?.instantiateViewController(withIdentifier: "ASResponse") as! ASResponseDetailViewController
            pushVC.receiveItems([item.shopName!, item.shopAddress!, item.aslType!, item.aslContent!, String(item.aslSeqno!), item.Client_cSeqno!])
            self.navigationController?.pushViewController(pushVC, animated: true)
        }
    }
}
