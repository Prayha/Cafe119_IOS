//
//  MyEngineerReviewDetailViewController.swift
//  Cafe119
//
//  Created by TJ on 2020/09/16.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit

class MyEngineerReviewDetailViewController: UIViewController {

    @IBOutlet weak var lblCName: UILabel!
    @IBOutlet weak var lblCScore: UILabel!
    @IBOutlet weak var tvCContent: UITextView!
    
    var receiveName = ""
    var receiveScore = ""
    var receiveContent = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        lblCName.text = receiveName
        lblCScore.text = (receiveScore + " / 5.0")
        tvCContent.text = receiveContent
    }
    
    func receiveItems(_ name:String, _ score:String, _ content:String) {
        receiveName = name
        receiveScore = score
        receiveContent = content
    }
}
