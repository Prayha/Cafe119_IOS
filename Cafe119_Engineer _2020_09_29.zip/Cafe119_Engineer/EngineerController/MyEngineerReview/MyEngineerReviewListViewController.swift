//
//  MyEngineerReviewViewController.swift
//  Cafe119
//
//  Created by TJ on 2020/09/16.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit

class MyEngineerReviewListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, MyEngineerReviewQueryModelProtocol {
    
    @IBOutlet weak var MyEngineerReviewListView: UITableView!
    
    var feedItem: NSArray = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tabBarController?.navigationController?.title = "나의 A/S 후기"
        
        let queryModel = MyEngineerReviewQueryModel()
        // query 사용을 위한 delegate
        queryModel.delegate = self
        queryModel.downloadItems()
        
        MyEngineerReviewListView.delegate = self
        MyEngineerReviewListView.dataSource = self
        MyEngineerReviewListView.rowHeight = 198
        
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func myEngineerReviewitemDownloaded(items: NSArray) {
        feedItem = items
        self.MyEngineerReviewListView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return feedItem.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EngineerMyReviewCell", for: indexPath) as! EngineerMyReviewTableViewCell
        // Configure the cell...
        let item: MyEngineerReviewDBModel = feedItem[indexPath.row] as! MyEngineerReviewDBModel // 배열로 되어있는 것을 class(DBModel) 타입으로 바꾼다.
                
        cell.cellView.layer.cornerRadius = 15
        cell.lblName.text = (item.name!)
        cell.lblTelno.text = (item.telno!)
        cell.lblRegion.text = (item.price!)
        cell.lblTrouble.text = (item.date!)
        cell.lblScore.text = (item.score! + " / 5.0")
        cell.lblContent.text = (item.content!)
       
        return cell
    }
    

    // MARK: - Navigation

        // In a storyboard-based application, you will often want to do a little preparation before navigation
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            // Get the new view controller using segue.destination.
            // Pass the selected object to the new view controller.
            
            if segue.identifier == "sgEngineerMyReviewDetail" {
                let cell = sender as! UITableViewCell
                let indexPath = self.MyEngineerReviewListView.indexPath(for: cell)
                print("indexpath : \(String(describing: indexPath))")
                
                let detailView = segue.destination as! MyEngineerReviewDetailViewController
                
    //            let item: DBModel = studentList[(indexPath! as NSIndexPath).row]
                let item: MyEngineerReviewDBModel = feedItem[(indexPath! as NSIndexPath).row] as! MyEngineerReviewDBModel
                let name = String(item.name!)
                let score = String(item.score!)
                let content = String(item.content!)
                
                detailView.receiveItems(name, score, content)
            }
        }

}
