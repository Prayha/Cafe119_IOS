//
//  EngineerLoginModel.swift
//  Cafe119
//
//  Created by 문단비 on 2020/09/17.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation
protocol EngineerLoginModelProtocol: class {
    func EngineerLoginChkDwonloaded(item: String)
}

class EngineerLoginModel: NSObject {
    
    // 로그인 아이디비밀번호확인
    var urlPath = URLPATH + "EngineerLoginChk_ios.jsp"
    var delegate: EngineerLoginModelProtocol!
    
    func EngineerloadItems(eId:String){
        // 한글 url encoding
        urlPath = urlPath.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        
        let urlAdd = "?eId=\(eId)"  // urlPath 뒤에 ? 물음표 부터 뒤에 넣을 것 세팅
        urlPath += urlAdd
        
        //        print(urlPath)
        
        let url: URL = URL(string: urlPath)!
        let defaultSession = Foundation.URLSession(configuration: URLSessionConfiguration.default)
        
        let task = defaultSession.dataTask(with: url) {(data, response, error) in
            if error != nil {
                print("Failed to download Data : \(String(describing: error))")
            } else {
                print("Data is downloaded")
                
                self.parserJson(data! as Data)
            }
        }
        
        task.resume()
    }
    
    
    func parserJson(_ data: Data) {
        
        // json Decoder
        let decoder = JSONDecoder()
        
        // json2 타입이 String 이기에 data 형식으로 변환
        let data2 = data
        
        // json 파싱
        if let enginnerclient = try? decoder.decode(EngineerSignUpDBModel2.self, from: data2) {
            print(enginnerclient.eSeqno! as String, "parserJson eSeqno")
            // 회원가입이 안되있는 아이디만 나옴
            
            ENGINEERDATA = enginnerclient
            
            
        }
        DispatchQueue.main.async(execute: {() -> Void in
            self.delegate.EngineerLoginChkDwonloaded(item: "NetworkSucess")
        })
    }
    
    
}
