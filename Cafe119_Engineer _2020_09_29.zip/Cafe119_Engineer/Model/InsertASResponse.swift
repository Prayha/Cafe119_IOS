//
//  InsertASResponse.swift
//  Cafe119_Engineer
//
//  Created by TJ on 2020/09/22.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation

class InsertASResponse: NSObject {
    
    var urlPath = URLPATH + "ASResponse_Insert_ios.jsp"
    
    func insertItems(price: String, arrivalTime: String, aslSeqno: Int, eSeqno: String) -> Bool { // 2
        var result: Bool = true
        let urlAdd = "?price=\(price)&arrivalTime=\(arrivalTime)&aslSeqno=\(aslSeqno)&eSeqno=\(eSeqno)" // urlPath 뒤에 입력할 내용을 추가하기위해 만든 변수
        urlPath = urlPath + urlAdd
        
        print("urlPath = \(urlPath)")
        
        // 한글 url encoding
        urlPath = urlPath.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        
        let url: URL = URL(string: urlPath)!
        let defaultSession = Foundation.URLSession(configuration: URLSessionConfiguration.default)
        
        let task = defaultSession.dataTask(with: url) {(data, response, error) in
            if error != nil {
                print("Failed to Insert Data : \(String(describing: error))")
                result = false
            } else {
                print("Data is Inserted")
                
                result = true
            }
        }
        
        task.resume()
        
        return result
    }
}
