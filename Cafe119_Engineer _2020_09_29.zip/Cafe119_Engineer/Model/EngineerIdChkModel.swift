//
//  EngineerIdChkModel.swift
//  Cafe119
//
//  Created by 문단비 on 2020/09/16.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation

protocol IdChkModelProtocol: class {
    func itemDownloaded(item: Int)
}

class IdChkModel: NSObject {

    var delegate: IdChkModelProtocol!
    
    func IdChkloadItems(eId: String){

        var urlPath = URLPATH + "EngineerIdlChk_ios.jsp?eId=\(eId)"
        
        // 한글 url encoding
        urlPath = urlPath.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        let url: URL = URL(string: urlPath)!
        let defaultSesstion = Foundation.URLSession(configuration: URLSessionConfiguration.default)
        let task = defaultSesstion.dataTask(with: url){(data, response, error) in
            if error != nil{
                print("Failed to insert data")

            }else{
                print("Data is inserted")
                self.parseJSON(data!)

            }
        }
        task.resume()
        
    }
    
    func parseJSON(_ data: Data) {
        var jsonResult = NSArray()
        var result = 0
        
           do {
               jsonResult = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments) as! NSArray
           } catch let error as NSError {
               print(error)
           }
           
           var jsonElement = NSDictionary()
           
           for i in 0..<jsonResult.count {
               jsonElement = jsonResult[i] as! NSDictionary
    
               if let count = jsonElement["count"] as? String {
//                print(result)
                result = Int(count)!
//                print(result)
               }
           }
        
           DispatchQueue.main.async(execute: {() -> Void in
//            print("delegare \(result)")
            self.delegate.itemDownloaded(item: result)
//            print("delegare \(result)")
           })
       }
    
    
    
    
}//-------------------------
