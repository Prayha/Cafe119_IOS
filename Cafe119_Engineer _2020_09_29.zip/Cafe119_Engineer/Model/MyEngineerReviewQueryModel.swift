//
//  MyEngineerReviewQueryModel.swift
//  Cafe119
//
//  Created by taeheum on 2020/09/16.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation

protocol MyEngineerReviewQueryModelProtocol: class {
    func myEngineerReviewitemDownloaded(items:NSArray)
}

class MyEngineerReviewQueryModel: NSObject{
    var delegate: MyEngineerReviewQueryModelProtocol!
    var urlPath = URLPATH + "EngineerMyReview.jsp"
    
    // downloadItems 괄호안에 uSeqno:String -> 로그인 완성 후
    func downloadItems(){
        let urlAdd = "?uSeqno=\((ENGINEERDATA?.eSeqno)!)"  // urlPath 뒤에 ? 물음표 부터 뒤에 넣을 것 세팅
        urlPath += urlAdd
        let url: URL = URL(string: urlPath)!
        let defaultSession = Foundation.URLSession(configuration: URLSessionConfiguration.default)
        let task = defaultSession.dataTask(with: url){(data, response, error) in
            if error != nil{
            }else{
                self.parseJAON(data!)
            }
        }
        task.resume()
    }
    func parseJAON(_ data: Data){
        var jsonResult = NSArray()
        
        do{
            jsonResult = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments) as! NSArray
        }catch let error as NSError{
            print(error)
        }
        var jsonElement = NSDictionary()
        let locations = NSMutableArray()
        
        for i in 0..<jsonResult.count{
            jsonElement = jsonResult[i] as! NSDictionary
            let query = MyEngineerReviewDBModel()
            // 첫번째 중괄호 안의 변수명 값들을 받아옴.
            if let name = jsonElement["name"] as? String,
                let telno = jsonElement["telno"] as? String,
                let price = jsonElement["price"] as? String,
                let date = jsonElement["date"] as? String,
                let content = jsonElement["content"] as? String,
                let score = jsonElement["score"] as? String
                {
               
                    query.name = name
                    query.telno = telno
                    query.price = price
                    query.date = date
                    query.content = content
                    query.score = score
                
            }
            
            locations.add(query)
        }
        DispatchQueue.main.async(execute: {() -> Void in
            self.delegate.myEngineerReviewitemDownloaded(items: locations)
        })
    }
}// ------------
