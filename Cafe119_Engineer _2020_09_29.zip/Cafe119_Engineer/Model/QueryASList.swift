//
//  QueryASList.swift
//  Cafe119_Engineer
//
//  Created by TJ on 2020/09/21.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation

protocol QueryASListProtocol: class {
    func itemDownloaded(items: NSArray, index: Int)
}

class QueryASList: NSObject {
    
    var delegate: QueryASListProtocol!
    let urlPath = URLPATH + "ASList_Select_All.jsp"
    
    func downloadItems() { // 2
        let url: URL = URL(string: urlPath)!
        let defaultSession = Foundation.URLSession(configuration: URLSessionConfiguration.default)
        
        let task = defaultSession.dataTask(with: url) {(data, response, error) in
            if error != nil {
                print("Failed to download Data : \(String(describing: error))")
            } else {
                print("Data is downloaded")
                
                self.parseJson(data!)
            }
        }
        
        task.resume()
    }
    
    func parseJson(_ data: Data) {
        let locations = NSMutableArray()
        
        // json Decoder
        let decoder = JSONDecoder()
        var count = 0

        if let asList = try? decoder.decode(ASLStatusDBModel.self, from: data) {
            for index in 0 ..< asList.aslStatus2.count {
                let list = ASListResponse(aslSeqno: asList.aslStatus2[index].aslSeqno!, shopName: asList.aslStatus2[index].shopName!, phone: asList.aslStatus2[index].phone!, aslType: asList.aslStatus2[index].aslType!, shopAddress: asList.aslStatus2[index].shopAddress!, aslContent: asList.aslStatus2[index].aslContent!, Client_cSeqno: asList.aslStatus2[index].Client_cSeqno!)
                locations.add(list)
                count = count + 1
            }
            
            for index in 0 ..< asList.aslStatus1.count {
                let list = ASListResponse(aslSeqno: asList.aslStatus1[index].aslSeqno!, shopName: asList.aslStatus1[index].shopName!, phone: asList.aslStatus1[index].phone!, aslType: asList.aslStatus1[index].aslType!, shopAddress: asList.aslStatus1[index].shopAddress!, aslContent: asList.aslStatus1[index].aslContent!, Client_cSeqno: asList.aslStatus1[index].Client_cSeqno!)
                locations.add(list)
            }
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.delegate.itemDownloaded(items: locations, index: count)
        })
    }
}

