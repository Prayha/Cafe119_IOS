//
//  ChatModel.swift
//  MessengerTutorial
//
//  Created by Changsu Lee on 2020/09/17.
//  Copyright © 2020 Changsu Lee. All rights reserved.
//

import Foundation

class ChatModel {
    
    var sender: String?
    var receiver: String?
    var message: String?
    var type: String?
    var isSeen: Bool
    //var time: TimeStamp?
    
    init(sender: String, receiver: String, message: String, type: String, isSeen: Bool//, time: TimeStamp
    ) {
        self.sender = sender
        self.receiver = receiver
        self.message = message
        self.type = type
        self.isSeen = isSeen
        //self.time = time
    }
    
}
