//
//  MyEngineerReviewDBModel.swift
//  Cafe119
//
//  Created by taeheum on 2020/09/16.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation

class MyEngineerReviewDBModel: NSObject {

    var name: String?
    var telno: String?
    var price: String?
    var date: String?
    var content: String?
    var score: String?

    // 비어있는 init
    override init() {
        
    }

    init(name: String, telno: String, price: String, date: String, content: String, score: String) {
        self.name = name
        self.telno = telno
        self.price = price
        self.date = date
        self.content = content
        self.score = score
    }

}
