//
//  ASLStatus.swift
//  Cafe119_Engineer
//
//  Created by Changsu Lee on 2020/09/25.
//  Copyright © 2020 Cafe119. All rights reserved.
//

import Foundation

class ASLStatusDBModel: Codable {
    var aslStatus2: [ASListResponse2]
    var aslStatus1: [ASListResponse2]
}
