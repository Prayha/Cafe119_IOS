//
//  ASResponseTableViewCell.swift
//  Cafe119_Engineer
//
//  Created by TJ on 2020/09/21.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit

class ASResponseTableViewCell: UITableViewCell {
    
    @IBOutlet var lblShopName: UILabel!
    @IBOutlet var lblPhone: UILabel!
    @IBOutlet var lblASLType: UILabel!
    @IBOutlet var lblShopAddress: UILabel!
}
