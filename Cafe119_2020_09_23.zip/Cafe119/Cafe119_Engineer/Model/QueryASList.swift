//
//  QueryASList.swift
//  Cafe119_Engineer
//
//  Created by TJ on 2020/09/21.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation

protocol QueryASListProtocol: class {
    func itemDownloaded(items: NSArray)
}

class QueryASList: NSObject {
    
    var delegate: QueryASListProtocol!
    let urlPath = "http://localhost:8080/Cafe119/ASList_Select_All.jsp"
    
    func downloadItems() { // 2
        let url: URL = URL(string: urlPath)!
        let defaultSession = Foundation.URLSession(configuration: URLSessionConfiguration.default)
        
        let task = defaultSession.dataTask(with: url) {(data, response, error) in
            if error != nil {
                print("Failed to download Data : \(String(describing: error))")
            } else {
                print("Data is downloaded")
                
                self.parseJson(data!)
            }
        }
        
        task.resume()
    }
    
    func parseJson(_ data: Data) {
        var jsonResult = NSArray()
        
        do {
            jsonResult = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments) as! NSArray
        } catch let error as NSError {
            print("Json Parse Error : \(error)")
        }
        
        var jsonElement = NSDictionary()
        let locations = NSMutableArray()
        
        for i in 0 ..< jsonResult.count {
            jsonElement = jsonResult[i] as! NSDictionary
            let query = ASListResponse()
            
            if let aslSeqno: Int = jsonElement["aslSeqno"] as? Int,
                let shopName: String = jsonElement["shopName"] as? String,
                let phone = jsonElement["phone"] as? String,
                let aslType = jsonElement["aslType"] as? String,
                let shopAddress = jsonElement["shopAddress"] as? String,
                let aslContent = jsonElement["aslContent"] as? String{
                query.aslSeqno = aslSeqno
                query.shopName = shopName
                query.phone = phone
                query.aslType = aslType
                query.shopAddress = shopAddress
                query.aslContent = aslContent
            }
            
            locations.add(query)
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.delegate.itemDownloaded(items: locations)
        })
    }
}

