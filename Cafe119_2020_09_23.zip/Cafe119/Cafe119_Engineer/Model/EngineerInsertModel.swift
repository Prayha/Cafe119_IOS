//
//  InsertModel.swift
//  ReviewLast
//
//  Created by Leo_Jang on 2020/09/22.
//  Copyright © 2020 Leo_Jang. All rights reserved.
//

import UIKit

class EngineerInsertModel: NSObject {
    
    var urlPath = "http://localhost:8080/test/EngineerReviewInsert.jsp"
    
    // 우리가 실행할 함수 (매개변수 들어간다, 리턴값(Bool)로 받는다 : 에러 처리용)
    
    func insertASR(erContent : String, erScore : String, Client_cSeqno : Int8, Engineer_eSeqno : Int8) -> Bool{
        
        //에러 처리용
        var result: Bool = true
        // "jsp" 뒤에 Get 방식으로 ?(물음표) 뒤에 넣어줄 부분.
        // 만약 값이 한글일 경우, url 에러가 나기 때문에. (2바이트를 %aluc 등등으로 바꿔야함)
        
        let urlAdd = "?erContent=\(erContent)&erScore=\(erScore)&Client_cSeqno=\(Client_cSeqno)&Engineer_eSeqno=\(Engineer_eSeqno)"
        
        // 완전한 url
        urlPath += urlAdd
        print(urlPath)
        
        // 한글 url encoding (utf8과는 아무런 상관이없다)
        urlPath = urlPath.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        
        let url: URL = URL(string: urlPath)!
        let defaultSession = Foundation.URLSession(configuration: URLSessionConfiguration.default)
        
        let task = defaultSession.dataTask(with: url){(data, response, error) in
            if error != nil {
                print("Failed to insert ASReview data")
                result = false
            }else{
                print("ASReview data is inserted")
                // --> 파싱을 하지 않는다.
                // self.parseJSON(data!)
                result = true
            }
        }
        task.resume()
        return result
    }
} // --------------------
