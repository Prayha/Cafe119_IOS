//
//  ShopReviewListViewController.swift
//  Cafe119
//
//  Created by TJ on 2020/09/16.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit

class ShopReviewListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, ShopReviewListQueryModelProtocol {

    @IBOutlet weak var ShopReviewListView: UITableView!
    
    var feedItem: NSArray = NSArray()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tabBarController?.navigationController?.title = "매장 후기"
        
        let queryModel = ShopReviewListQueryModel()
        // query 사용을 위한 delegate
        queryModel.delegate = self
        queryModel.downloadItems()
        
        ShopReviewListView.delegate = self
        ShopReviewListView.dataSource = self
        ShopReviewListView.rowHeight = 160
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func shopReviewitemDownloaded(items: NSArray) {
        feedItem = items
        self.ShopReviewListView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return feedItem.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ShopReivewListCell", for: indexPath) as! ShopReviewListTableViewCell
        // Configure the cell...
        let item: ShopReviewListDBModel = feedItem[indexPath.row] as! ShopReviewListDBModel // 배열로 되어있는 것을 class(DBModel) 타입으로 바꾼다.
                
        cell.viewCell.layer.cornerRadius = 15
        cell.lblName.text = (item.name!)
        cell.lblTelno.text = (item.telno!)
        cell.lblRegion.text = (item.region!)
        cell.lblTrouble.text = (item.trouble!)
        cell.lblContent.text = (item.content!)
       
        return cell
    }

    // MARK: - Navigation

        // In a storyboard-based application, you will often want to do a little preparation before navigation
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            // Get the new view controller using segue.destination.
            // Pass the selected object to the new view controller.
            
            if segue.identifier == "sgShopReviewDetail" {
                let cell = sender as! UITableViewCell
                let indexPath = self.ShopReviewListView.indexPath(for: cell)
                print("indexpath : \(String(describing: indexPath))")
                
                let detailView = segue.destination as! ShopReviewDetailViewController
                
    //            let item: DBModel = studentList[(indexPath! as NSIndexPath).row]
                let item: ShopReviewListDBModel = feedItem[(indexPath! as NSIndexPath).row] as! ShopReviewListDBModel
                let name = String(item.name!)
                let score = String(item.score!)
                let content = String(item.content!)
                
                detailView.receiveItems(name, score, content)
            }
        }

}
