//
//  ASResponseDetailViewController.swift
//  Cafe119
//
//  Created by TJ on 2020/09/16.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit

class ASResponseDetailViewController: UIViewController {

    @IBOutlet var lblShopName: UILabel!
    @IBOutlet var lblShopAddress: UILabel!
    @IBOutlet var lblContent: UILabel!
    @IBOutlet var tfPrice: UITextField!
    @IBOutlet var ASArrivalTime: UIDatePicker!
    
    var eSeqno = 2
    
    var receiveItems: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblShopName.text = receiveItems[0]
        lblShopAddress.text = receiveItems[1]
        lblContent.text = receiveItems[2] + "\n\n" + receiveItems[3]
        
        tfPrice.keyboardType = .numberPad
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    func receiveItems(_ items: [String]){
        receiveItems = items
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    @IBAction func btnASResponse(_ sender: UIButton) {
        print(receiveItems[4])
        print(eSeqno)
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        
        print(formatter.string(from: ASArrivalTime.date))
        
        let insertASResponse = InsertASResponse()
        let result: Bool = insertASResponse.insertItems(price: tfPrice.text! + "원", arrivalTime: formatter.string(from: ASArrivalTime.date), aslSeqno: Int(receiveItems[4])!, eSeqno: eSeqno)
        if result {
            let resultAlert = UIAlertController(title: "완료", message: "입력이 되었습니다.", preferredStyle: UIAlertController.Style.alert)
            let onAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
            resultAlert.addAction(onAction)
            present(resultAlert, animated: true, completion: nil)
        } else {
            let resultAlert = UIAlertController(title: "실패", message: "에러가 발생 되었습니다.", preferredStyle: UIAlertController.Style.alert)
            let onAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
            resultAlert.addAction(onAction)
            present(resultAlert, animated: true, completion: nil)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
