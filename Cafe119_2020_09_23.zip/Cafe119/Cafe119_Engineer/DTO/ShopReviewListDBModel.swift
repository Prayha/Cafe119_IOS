//
//  ShopReviewListDBModel.swift
//  Cafe119
//
//  Created by taeheum on 2020/09/18.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation

class ShopReviewListDBModel: NSObject {

    var name: String?
    var telno: String?
    var region: String?
    var trouble: String?
    var content: String?
    var score: String?

    // 비어있는 init
    override init() {
        
    }

    init(name: String, telno: String, region: String, trouble: String, content: String, score: String) {
        self.name = name
        self.telno = telno
        self.region = region
        self.trouble = trouble
        self.content = content
        self.score = score
    }

}
