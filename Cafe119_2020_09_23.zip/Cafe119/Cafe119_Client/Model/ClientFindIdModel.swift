//
//  ClientFindIdModel.swift
//  Cafe119
//
//  Created by 문단비 on 2020/09/20.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation

protocol ClientFindIdPwModelProtocol: class {
    func FindIditemDownloaded(name: String, email: String, id: String)
    func FindPwitemDownloaded(name: String, id: String, pw: String)
}

class ClientFindIdModel: NSObject {
    
    var delegate: ClientFindIdPwModelProtocol!
    var urlPath = "http://localhost:8080/Cafe119/ClientFindId_ios.jsp"
    
    func downloadItems(cName: String, cEmail: String){
        
        let urlAdd = "?cName=\(cName)&cEmail=\(cEmail)"
        
        urlPath += urlAdd
        
        // 한글 url encoding
        urlPath = urlPath.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        let url: URL = URL(string: urlPath)!
        print(url)
        let defaultSesstion = Foundation.URLSession(configuration: URLSessionConfiguration.default)
        let task = defaultSesstion.dataTask(with: url){(data, response, error) in
            if error != nil{
                print("Failed to select data")
            }else{
                print("Data is selected")
                self.parserJson(data!)
                
            }
        }
        task.resume()
        
    }
    
    func parserJson(_ data: Data) {
        //        var jsonResult = NSArray()
        var jsonResult = NSDictionary()
        
        do {
            jsonResult = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments) as! NSDictionary
        } catch let error as NSError {
            print(error)
        }
        
        let locations = NSMutableArray()
        
        let query = ClientLoginUpDBModel()
        var name: String = ""
        var email: String = ""
        var id: String = ""
        
        if let cId = jsonResult["cId"] as? String,
            let cName = jsonResult["cName"] as? String,
            let cEmail = jsonResult["cEmail"] as? String {
            
            query.cId = cId
            query.cName = cName
            query.cEmail = cEmail
            
            name = cName
            email = cEmail
            id = cId
        }
        
        locations.add(query)
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.delegate.FindIditemDownloaded(name: name, email: email, id: id)
        })
    }
    
    
    
    // -----------   비밀번호   ----------- \\
    
    var urlPath2 = "http://localhost:8080/Cafe119/ClientFindPassWord_ios.jsp"
    
    func downloadItems2(cId: String, cName: String){
        
        let urlAdd = "?cId=\(cId)&cName=\(cName)"
        
        urlPath2 += urlAdd
        
        // 한글 url encoding
        urlPath2 = urlPath2.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        let url: URL = URL(string: urlPath2)!
        print(url)
        let defaultSesstion = Foundation.URLSession(configuration: URLSessionConfiguration.default)
        let task = defaultSesstion.dataTask(with: url){(data, response, error) in
            if error != nil{
                print("Failed to select data")
            }else{
                print("Data is selected")
                self.parserJson2(data!)
                
            }
        }
        task.resume()
        
    }
    
    func parserJson2(_ data: Data) {
        //        var jsonResult = NSArray()
        var jsonResult = NSDictionary()
        
        do {
            jsonResult = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments) as! NSDictionary
        } catch let error as NSError {
            print(error)
        }
        
        let locations = NSMutableArray()
        
        let query = ClientLoginUpDBModel()
        var name: String = ""
        var id: String = ""
        var pw: String = ""
        
        if let cPw = jsonResult["cPw"] as? String,
            let cName = jsonResult["cName"] as? String,
            let cId = jsonResult["cId"] as? String {
            
            query.cId = cId
            query.cPw = cPw
            query.cName = cName
            
            name = cName
            id = cId
            pw = cPw
        }
        
        locations.add(query)
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.delegate.FindPwitemDownloaded(name: name, id: id, pw: pw)
        })
    }
    
    
    
    
}//--------------------------

