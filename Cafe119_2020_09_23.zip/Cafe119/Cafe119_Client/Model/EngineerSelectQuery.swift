//
//  EngineerSelectQuery.swift
//  Cafe119_Customer
//
//  Created by TJ on 2020/09/22.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation

protocol EngineerSelectQueryProtocol: class {
    func itemDownloaded(items: NSArray)
}

class EngineerSelectQuery: NSObject {
    
    var delegate: EngineerSelectQueryProtocol!
    var urlPath = "http://127.0.0.1:8080/Cafe119/Engineer_Select_Query.jsp"
    
    func downloadItems(cSeqno: Int) { // 2
        urlPath += "?cSeqno=\(cSeqno)"
        let url: URL = URL(string: urlPath)!
        let defaultSession = Foundation.URLSession(configuration: URLSessionConfiguration.default)
        
        let task = defaultSession.dataTask(with: url) {(data, response, error) in
            if error != nil {
                print("Failed to download Data : \(String(describing: error))")
            } else {
                print("Data is downloaded")
                
                self.parseJson(data!)
            }
        }
        
        task.resume()
    }
    
    func parseJson(_ data: Data) {
        var jsonResult = NSArray()
        
        do {
            jsonResult = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments) as! NSArray
        } catch let error as NSError {
            print("Json Parse Error : \(error)")
        }
        
        var jsonElement = NSDictionary()
        let locations = NSMutableArray()
        
        for i in 0 ..< jsonResult.count {
            jsonElement = jsonResult[i] as! NSDictionary
            let query = EngineerSelect()
            
            if let engineerName: String = jsonElement["engineerName"] as? String,
                let engineerPhone = jsonElement["engineerPhone"] as? String,
                let price = jsonElement["price"] as? String,
                let arrivalTime = jsonElement["arrivalTime"] as? Int,
                let eSeqno = jsonElement["eSeqno"] as? Int{
                
                query.engineerName = engineerName
                query.engineerPhone = engineerPhone
                query.price = price
                query.arrivalTime = arrivalTime
                query.eSeqno = eSeqno
            }
            
            locations.add(query)
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.delegate.itemDownloaded(items: locations)
        })
    }
}
