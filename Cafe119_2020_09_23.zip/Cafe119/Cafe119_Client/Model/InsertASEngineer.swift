//
//  InsertASEngineer.swift
//  Cafe119_Customer
//
//  Created by TJ on 2020/09/22.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation

class InsertASEngineer: NSObject {
    
    var urlPath = "http://127.0.0.1:8080/Cafe119/Insert_AS_Engineer.jsp"
    
    func insertItems(cSeqno: Int, eSeqno: Int) -> Bool { // 2
        var result: Bool = true
        let urlAdd = "?cSeqno=\(cSeqno)&eSeqno=\(eSeqno)" // urlPath 뒤에 입력할 내용을 추가하기위해 만든 변수
        urlPath = urlPath + urlAdd
        
        // 한글 url encoding
        urlPath = urlPath.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        
        let url: URL = URL(string: urlPath)!
        let defaultSession = Foundation.URLSession(configuration: URLSessionConfiguration.default)
        
        let task = defaultSession.dataTask(with: url) {(data, response, error) in
            if error != nil {
                print("Failed to Insert Data : \(String(describing: error))")
                result = false
            } else {
                print("Data is Inserted")
                
                result = true
            }
        }
        
        task.resume()
        
        return result
    }
}
