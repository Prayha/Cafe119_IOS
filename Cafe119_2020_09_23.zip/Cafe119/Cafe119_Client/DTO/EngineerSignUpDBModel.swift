//
//  EngineerSignUp.swift
//  Cafe119
//
//  Created by 문단비 on 2020/09/16.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation

struct EngineerSignUpDBModel2: Codable {
    var eSeqno: String?
    var eId: String?
    var ePw: String?
    var eName: String?
    var eEmail: String?
    var eImage: String?
    var eTelno: String?
    var eBusinessNumber: String?
    var eDate: String?
    var eAddress: String?
}

class EngineerSignUpDBModel: NSObject{
    var eSeqno: String?
    var eId: String?
    var ePw: String?
    var eName: String?
    var eEmail: String?
    var eImage: String?
    var eTelno: String?
    var eBusinessNumber: String?
    var eDate: String?
    var eAddress: String?
    
    override init() {
        
    }
    //eSeqno, eId, ePw, eName, eEmail, eImage, eTelno, eBusinessNumber, eDate, eAddress
    
    init (eSeqno: String, eId: String, ePw: String, eName: String, eEmail: String, eImage: String, eTelno: String, eBusinessNumber: String, eDate: String, eAddress: String) {
        self.eSeqno = eSeqno
        self.eId = eId
        self.ePw = ePw
        self.eName = eName
        self.eEmail = eEmail
        self.eImage = eImage
        self.eTelno = eTelno
        self.eBusinessNumber = eBusinessNumber
        self.eDate = eDate
        self.eAddress = eAddress
    }
    
}
