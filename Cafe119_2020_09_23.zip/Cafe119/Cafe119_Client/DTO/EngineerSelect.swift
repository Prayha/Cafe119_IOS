//
//  EngineerSelect.swift
//  Cafe119_Customer
//
//  Created by TJ on 2020/09/22.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation

class EngineerSelect: NSObject{
    
    var engineerName: String?
    var engineerPhone: String?
    var price: String?
    var arrivalTime: Int?
    var eSeqno: Int?
    
    override init(){
        
    }
    
    init(engineerName: String, engineerPhone: String, price: String, arrivalTime: Int, eSeqno: Int){
        self.engineerName = engineerName
        self.engineerPhone = engineerPhone
        self.price = price
        self.arrivalTime = arrivalTime
        self.eSeqno = eSeqno
    }
}
