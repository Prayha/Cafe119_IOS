//
//  TransViewController.swift
//  Cafe119
//
//  Created by TJ on 2020/09/16.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit

class TransViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, MyClientReviewQueryModelProtocol {
    
    @IBOutlet weak var MyClientReviewListView: UITableView!
    
    var feedItem: NSArray = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        let queryModel = MyClientReviewQueryModel()
        // query 사용을 위한 delegate
        queryModel.delegate = self
        queryModel.downloadItems()
        
        MyClientReviewListView.delegate = self
        MyClientReviewListView.dataSource = self
        MyClientReviewListView.rowHeight = 200
        
        self.tabBarController?.navigationItem.setHidesBackButton(true, animated: true)
        
    }
    
    func myClientReviewitemDownloaded(items: NSArray) {
        feedItem = items
        self.MyClientReviewListView.reloadData()
    }
    
    // MARK: - Table
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
        
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return feedItem.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ClientMyReviewCell", for: indexPath) as! ClientMyReviewTableViewCell
        // Configure the cell...
        let item: MyClientReviewDBModel = feedItem[indexPath.row] as! MyClientReviewDBModel // 배열로 되어있는 것을 class(DBModel) 타입으로 바꾼다.
        
        cell.lblName.text = (item.name!)
        cell.lblTelno.text = (item.telno!)
        cell.lblTrouble.text = (item.trouble!)
        cell.lblAddress.text = (item.address!)
        cell.lblScore.text = (item.score! + " / 5.0")
        cell.lblContent.text = (item.content!)
        
        return cell
    }
    
    // MARK: - Prepare
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "sgClientMyReviewDetail" {
            let cell = sender as! UITableViewCell
            let indexPath = self.MyClientReviewListView.indexPath(for: cell)
            print("indexpath : \(String(describing: indexPath))")
            
            let detailView = segue.destination as! CustomerASReviewViewController
            
            //            let item: DBModel = studentList[(indexPath! as NSIndexPath).row]
            let item: MyClientReviewDBModel = feedItem[(indexPath! as NSIndexPath).row] as! MyClientReviewDBModel
            let name = String(item.name!)
            let score = String(item.score!)
            let content = String(item.content!)
            
            detailView.receiveItems(name, score, content)
        }
    }
    
    // MARK: - ButtonEvent
    @IBAction func ASRequestButton(_ sender: UIButton) {
        let pushVC = self.storyboard?.instantiateViewController(withIdentifier: "ASRequestView")
        self.navigationController?.pushViewController(pushVC!, animated: true)
    }
}
