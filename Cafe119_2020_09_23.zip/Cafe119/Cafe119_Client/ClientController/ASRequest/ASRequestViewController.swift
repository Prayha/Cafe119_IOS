//
//  ASRequestViewController.swift
//  Cafe119
//
//  Created by TJ on 2020/09/16.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit
import ARKit

class ASRequestViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    @IBOutlet var objectConditionImage: UIImageView!
    
    @IBOutlet var btnMachine: UIButton!
    @IBOutlet var btnGrinder: UIButton!
    
    let imagePickerController = UIImagePickerController()
    
    @IBOutlet var tvContent: UITextView!
    
    @IBOutlet var ASDatePicker: UIDatePicker!
    
    var imageURL: URL?
    var ASType: String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagePickerController.delegate = self
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(touchToPickPhoto))
        objectConditionImage.addGestureRecognizer(tapGesture)
        objectConditionImage.isUserInteractionEnabled = true
    }
    
    // MARK: - Upload
    @IBAction func btnInsert(_ sender: UIButton) {
        
        if imageURL == nil {
            myAlert(alertTitle: "오류", alertMessage: "이미지를 가져와주세요.", actionTitle: "OK", handler: nil)
            return
        }
        
        if ASType == "" {
            myAlert(alertTitle: "오류", alertMessage: "기기를 골라주세요.", actionTitle: "OK", handler: nil)
            return
        }
        
        let reviewInsertModel = ReviewInsertModel()
        reviewInsertModel.uploadImageFile(at: imageURL!, url: URL(string: URLPATH + "AS_Insert_ios.jsp")!, parameters: ["ASType" : ASType, "ASContent" : tvContent.text!, "cSeqno" : String(USERDATA!.cSeqno)], completionHandler: {_,_ in })
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
                objectConditionImage.image = image
                
                imageURL = info[UIImagePickerController.InfoKey.imageURL] as? URL
            }
            
            // 켜놓은 앨범 화면 없애기
            dismiss(animated: true, completion: nil)
        }
    
    @objc func touchToPickPhoto(){
        imagePickerController.sourceType = .photoLibrary
        self.present(imagePickerController, animated: true, completion: nil)
    }
    
    @IBAction func btnCoffeeMachine(_ sender: UIButton) {
        btnMachine.isUserInteractionEnabled = false
        btnGrinder.isUserInteractionEnabled = true
        btnMachine.setTitleColor(.gray, for: .normal)
        btnGrinder.setTitleColor(.blue, for: .normal)
        ASType = "커피 머신"
    }
    
    @IBAction func btnCoffeeGrinder(_ sender: UIButton) {
        btnMachine.isUserInteractionEnabled = true
        btnGrinder.isUserInteractionEnabled = false
        btnMachine.setTitleColor(.blue, for: .normal)
        btnGrinder.setTitleColor(.gray, for: .normal)
        ASType = "커피 그라인더"
    }
    
    // MARK: - Alert
    
    func myAlert(alertTitle: String, alertMessage: String, actionTitle: String, handler:((UIAlertAction) -> Void)?) {
        let resultAlert = UIAlertController(title: alertTitle, message: alertMessage, preferredStyle: UIAlertController.Style.alert)
        let onAction = UIAlertAction(title: actionTitle, style: UIAlertAction.Style.default, handler: handler)
        resultAlert.addAction(onAction)
        present(resultAlert, animated: true, completion: nil)
    }
}
