//
//  ClientSignUpViewController.swift
//  Cafe119
//
//  Created by TJ on 2020/09/16.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit
import MapKit

class ClientSignUpViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate, ClientIdChkModelProtocol {
    
    
    
    @IBOutlet weak var btnImage: UIButton!
    @IBOutlet weak var tfId: UITextField!
    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var tfPw: UITextField!
    @IBOutlet weak var tfPwChk: UITextField!
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfPhone: UITextField!
    @IBOutlet weak var tfAddress: UITextField!
    @IBOutlet weak var tfBusinessRegistration: UITextField! // 사업자 등록증
    
    let imagePickerController = UIImagePickerController()
    
    var imageURL: URL?
    var IdCheckResult: Int = 2
    
    let locationManager = CLLocationManager()
    
    var checkedId = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        imagePickerController.delegate = self
        
        tfName.isEnabled = false
        tfPw.isEnabled = false
        tfPw.isEnabled = false
        tfPwChk.isEnabled = false
        tfEmail.isEnabled = false
        tfAddress.isEnabled = false
        tfPhone.isEnabled = false
        tfBusinessRegistration.isEnabled = false
    }
    
    @IBAction func btnPhoto(_ sender: UIButton) {
        // 앨범 호출
        imagePickerController.sourceType = .photoLibrary
        self.present(imagePickerController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            
            btnImage.setImage(image, for: UIControl.State.normal)
            
            imageURL = info[UIImagePickerController.InfoKey.imageURL] as? URL
        }
        
        // 켜놓은 앨범 화면 없애기
        dismiss(animated: true, completion: nil)
    }
    
    
    // 가입하기
    @IBAction func btnSignUp(_ sender: UIButton) {
        
        let Id = tfId.text!.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: " ", with: "")
        let Name = tfName.text!.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: " ", with: "")
        let Password = tfPw.text!.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: " ", with: "")
        let chkPassword = tfPwChk.text!.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: " ", with: "")
        let Email = tfEmail.text!.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: " ", with: "")
        let Phone = tfPhone!.text!.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "", with: "")
        let Region = tfAddress.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        print("Region : " + Region)
        let BusinessRegistration = tfBusinessRegistration!.text!.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: " ", with: "")
        
        self.Check(Password, Name, chkPassword, Id, Phone, Region, BusinessRegistration, Email)
    }
    
    
    func login(_ Password:String, _ Name:String, _ chkPassword:String, _ Id:String, _ Phone:String, _ Region:String, _ BusinessRegistration:String, _ Email:String) {
        var latitude : Double = 0.0
        var longitude : Double = 0.0
        
        getLocation(from: Region) { location in
            if location == nil {
                self.myAlert(alertTitle: "실패", alertMessage: "주소를 정확히 입력해주세요.", actionTitle: "OK", handler: nil)
                
                return
            }
            
            // Location is Optional(__C.CLLocationCoordinate2D(latitude: 39.799372, longitude: -89.644458))
            latitude = location!.latitude
            longitude = location!.longitude
            print(location!.latitude)
            print(location!.longitude)
            
            let parameters = [
                "Id" : Id,
                "Name" : Name,
                "Password" : Password,
                "Email" : Email,
                "Phone" : Phone,
                "Region" : Region,
                "BusinessRegistration" : BusinessRegistration,
                "Latitude" : String(latitude),
                "Longitude" : String(longitude)
            ]
            
            if self.validatePassword(password: Password){
                //            print("성공")
            }else{
                self.myAlert(alertTitle: "실패", alertMessage: "최소 8글자이상, 대문자, 소문자, 숫자 조합으로 입력해주새요.", actionTitle: "OK", handler: nil)
                //            print("실패")
            }
            
            if self.tfPwChk.text == self.tfPw.text{
                let resultAlert = UIAlertController(title: "완료", message: "회원가입에 성공했습니다.", preferredStyle: UIAlertController.Style.alert)
                let  onAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: {Action in
                    // 전화면으로 넘어가기위한것
                    self.navigationController?.popViewController(animated: true)
                    
                    let singupModel = ClientSignUpModel()
                    
                    
                    
                    singupModel.uploadImageFile(at: self.imageURL!, parameters: parameters, completionHandler: {_,_ in})
                    
                })
                resultAlert.addAction(onAction)
                self.present(resultAlert, animated: true, completion: nil)
                
                
                
            } else {
                let resultAlert = UIAlertController(title: "실패", message: "비밀번호가 일치하지 않습니다.", preferredStyle: UIAlertController.Style.alert)
                let  onAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
                resultAlert.addAction(onAction)
                self.present(resultAlert, animated: true, completion: nil)
            }
            
        }
    }
    
    // 위도 경도 받는함수
    func getLocation(from address: String, completion: @escaping (_ location: CLLocationCoordinate2D?)-> Void) {
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(address) { (placemarks, error) in
            guard let placemarks = placemarks,
                let location = placemarks.first?.location?.coordinate else {
                    completion(nil)
                    return
            }
            completion(location)
        }
    }
    
    // 중복확인
    @IBAction func btnDoubleCheck(_ sender: UIButton) {
        let Id = tfId.text!
        
        let Idchk = ClientIdChkModel()
        Idchk.delegate = self
        Idchk.ClientIdChkloadItems(cId: Id)
        
    }
    func itemDownloaded(item: Int) {
        IdCheckResult = item
        
        if tfId.text == "" {
            myAlert(alertTitle: "실패", alertMessage: "아이디 입력해주세요.", actionTitle: "OK", handler: nil)
        } else if IdCheckResult == 0 {
            print("IdCheckResult \(IdCheckResult)")
            myAlert(alertTitle: "확인", alertMessage: "사용가능한 아이디입니다.", actionTitle: "OK", handler: nil)
            tfName.isEnabled = true
            tfPw.isEnabled = true
            tfPw.isEnabled = true
            tfPwChk.isEnabled = true
            tfEmail.isEnabled = true
            tfAddress.isEnabled = true
            tfBusinessRegistration.isEnabled = true
            tfPhone.isEnabled = true
            checkedId = true
        } else {
            //            print("IdCheckResult \(IdCheckResult)")
            myAlert(alertTitle: "아이디 중복", alertMessage: "이미 사용중인 아이디입니다.", actionTitle: "OK", handler: nil)
        }
    }
        
    //    password, chkpassword, Id, Phone, Address, BusinessRegistration
    func Check(_ Password:String, _ Name:String, _ chkPassword:String, _ Id:String, _ Phone:String, _ Region:String, _ BusinessRegistration:String, _ Email:String){
        if !checkedId {
            myAlert(alertTitle: "실패", alertMessage: "이메일 중복체크를 해주세요", actionTitle: "OK", handler: nil)
        } else if Id.isEmpty {
            myAlert(alertTitle: "실패", alertMessage: "아이디를 입력해주세요", actionTitle: "OK", handler: nil)
        } else if Name.isEmpty {
            myAlert(alertTitle: "실패", alertMessage: "이름을 입력해주세요", actionTitle: "OK", handler: nil)
        } else if Password.isEmpty {
            myAlert(alertTitle: "실패", alertMessage: "비밀번호를 입력해주세요", actionTitle: "OK", handler: nil)
        } else if Email.isEmpty {
            myAlert(alertTitle: "실패", alertMessage: "이메일을 입력해주세요.", actionTitle: "OK", handler: nil)
        } else if !isValidEmail(emailStr: Email) {
            myAlert(alertTitle: "실패", alertMessage: "이메일 형식으로 입력해주세요.", actionTitle: "OK", handler: nil)
        } else if Phone.isEmpty {
            myAlert(alertTitle: "실패", alertMessage: "전화번호를 입력해주세요.", actionTitle: "OK", handler: nil)
        } else if !isPhone(candidate: Phone){
            myAlert(alertTitle: "실패", alertMessage: "전화번호는 숫자만 입력해주세요.", actionTitle: "OK", handler: nil)
        } else if Region.isEmpty {
            myAlert(alertTitle: "실패", alertMessage: "주소를 입력해주세요.", actionTitle: "OK", handler: nil)
        } else if BusinessRegistration.isEmpty {
            myAlert(alertTitle: "실패", alertMessage: "사업자 등록증을 입력해주세요.", actionTitle: "OK", handler: nil)
        }  else if imageURL == nil {
            myAlert(alertTitle: "실패", alertMessage: "사진을 등록해주세요.", actionTitle: "OK", handler: nil)
        } else {
            login(Password, Name, chkPassword, Id, Phone, Region, BusinessRegistration, Email)
        }
    }
        
    func myAlert(alertTitle: String, alertMessage: String, actionTitle: String, handler:((UIAlertAction) -> Void)?) {
        let resultAlert = UIAlertController(title: alertTitle, message: alertMessage, preferredStyle: UIAlertController.Style.alert)
        let onAction = UIAlertAction(title: actionTitle, style: UIAlertAction.Style.default, handler: handler)
        resultAlert.addAction(onAction)
        present(resultAlert, animated: true, completion: nil)
    }
    
    // 이메일
    func isValidEmail(emailStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: emailStr)
    }
    
    // 패스워드
    func validatePassword(password:String) -> Bool {
        let passwordRegEx = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z]).{8,24}$"
        
        let predicate = NSPredicate(format:"SELF MATCHES %@", passwordRegEx)
        return predicate.evaluate(with: password)
    }
    
    // 전화번호
    func isPhone(candidate: String) -> Bool {
        
        let regex = "^01([0|1|6|7|8|9]?)([0-9]{3,4})([0-9]{4})$"
        return NSPredicate(format: "SELF MATCHES %@", regex).evaluate(with: candidate)
        
    }
    
}
