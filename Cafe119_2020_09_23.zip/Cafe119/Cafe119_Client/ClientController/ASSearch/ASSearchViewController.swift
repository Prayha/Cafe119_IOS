//
//  ASSearchViewController.swift
//  Cafe119
//
//  Created by TJ on 2020/09/16.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit

class ASSearchViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, RepairReviewListQueryModelProtocol {
    
    @IBOutlet weak var RepairReviewListView: UITableView!
    @IBOutlet weak var tfComment: UITextField!
    
    var feedItem: NSArray = NSArray()
    
    let queryModel = RepairReviewListQueryModel()
    
    let searchController = UISearchController(searchResultsController: nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // query 사용을 위한 delegate
        queryModel.delegate = self
        queryModel.downloadItems(comment: "")
        
        RepairReviewListView.delegate = self
        RepairReviewListView.dataSource = self
        RepairReviewListView.rowHeight = 200
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func repairReviewitemDownloaded(items: NSArray) {
        feedItem = items
        self.RepairReviewListView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return feedItem.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RepairReivewListCell", for: indexPath) as! ASSearchTableViewCell
        // Configure the cell...
        let item: RepairReviewListDBModel = feedItem[indexPath.row] as! RepairReviewListDBModel // 배열로 되어있는 것을 class(DBModel) 타입으로 바꾼다.
        
        cell.lblName.text = (item.name!)
        cell.lblTelno.text = (item.telno!)
        cell.lblPrice.text = "출장 가격 : \(item.price!)"
        cell.lblContent.text = (item.content!)
        cell.lblScore.text = "후기 점수 \(item.score!) / 5.0"
        
        return cell
    }
    
    
    @IBAction func btnSearch(_ sender: UIButton) {
        if let comment = tfComment.text {
            queryModel.downloadItems(comment: comment)
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "sgRepairReviewDetail" {
            let cell = sender as! UITableViewCell
            let indexPath = self.RepairReviewListView.indexPath(for: cell)
            print("indexpath : \(String(describing: indexPath))")
            
            let detailView = segue.destination as! ASSerachDetailViewController
            
            //            let item: DBModel = studentList[(indexPath! as NSIndexPath).row]
            let item: RepairReviewListDBModel = feedItem[(indexPath! as NSIndexPath).row] as! RepairReviewListDBModel
            let name = String(item.name!)
            let score = String(item.score!)
            let content = String(item.content!)
            
            detailView.receiveItems(name, score, content)
        }
    }
    
}

