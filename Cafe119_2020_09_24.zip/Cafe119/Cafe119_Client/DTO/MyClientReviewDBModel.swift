//
//  MyClientReviewDBModel.swift
//  Cafe119
//
//  Created by taeheum on 2020/09/17.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation

class MyClientReviewDBModel: NSObject {

    var name: String?
    var telno: String?
    var trouble: String?
    var address: String?
    var score: String?
    var content: String?

    // 비어있는 init
    override init() {
        
    }

    init(name: String, telno: String, trouble: String, address: String, score: String, content: String) {
        self.name = name
        self.telno = telno
        self.trouble = trouble
        self.address = address
        self.score = score
        self.content = content
    }

}
