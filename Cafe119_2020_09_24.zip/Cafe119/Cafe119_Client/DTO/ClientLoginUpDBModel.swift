//
//  ClientLoginUpDBModel.swift
//  Cafe119
//
//  Created by 문단비 on 2020/09/17.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation

// json Data 받을 구조체
struct ClientLoginUpDBModel2: Codable {
    var cSeqno: String
    var cId: String
    var cPw: String
    var cName: String
    var cEmail: String
    var cImage: String
    var cTelno: String
    var cBusinessNumber: String
    var cDate: String
    var cRegion: String
    var cLatitude: String
    var cLongitude: String
}

class ClientLoginUpDBModel: NSObject{
    var cSeqno: String?
    var cId: String?
    var cPw: String?
    var cName: String?
    var cEmail: String?
    var cImage: String?
    var cTelno: String?
    var cBusinessNumber: String?
    var cDate: String?
    var cRegion: String?
    var cLatitude: String?
    var cLongitude: String?

    override init() {
        
    }
    
    init (cSeqno: String, cId: String, cPw: String, cName: String, cEmail: String, cImage: String, cTelno: String, cBusinessNumber: String, cDate: String, cRegion: String,cLatitude: String, cLongitude:String) {
        self.cSeqno = cSeqno
        self.cId = cId
        self.cPw = cPw
        self.cName = cName
        self.cEmail = cEmail
        self.cImage = cImage
        self.cTelno = cTelno
        self.cBusinessNumber = cBusinessNumber
        self.cDate = cDate
        self.cRegion = cRegion
        self.cLatitude = cLatitude
        self.cLongitude = cLongitude
    }
    
}
