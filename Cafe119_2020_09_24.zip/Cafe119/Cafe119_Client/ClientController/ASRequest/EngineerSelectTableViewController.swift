//
//  EngineerSelectTableViewController.swift
//  Cafe119_Customer
//
//  Created by TJ on 2020/09/22.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit

class EngineerSelectTableViewController: UITableViewController, EngineerSelectQueryProtocol {

    @IBOutlet var engineerSelectTableView: UITableView!
    
    var feedItem : NSArray = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        engineerSelectTableView.delegate = self
        engineerSelectTableView.dataSource = self
        
        let engineerSelectQuery = EngineerSelectQuery()
        engineerSelectQuery.delegate = self
        engineerSelectQuery.downloadItems(cSeqno: USERDATA!.cSeqno)
    }
    
    func itemDownloaded(items: NSArray) {
        feedItem = items
        engineerSelectTableView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        let engineerSelectQuery = EngineerSelectQuery()
        engineerSelectQuery.delegate = self
        engineerSelectQuery.downloadItems(cSeqno: USERDATA!.cSeqno)
    }

    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return feedItem.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as! EngineerSelectTableViewCell
        
        let item : EngineerSelect = feedItem[indexPath.row] as! EngineerSelect
        
        let hour = item.arrivalTime! / 60
        let minute = item.arrivalTime! % 60
        
        cell.lblEngineerName.text = item.engineerName
        cell.lblPhone.text = "연락처 : " + item.engineerPhone!
        cell.lblPrice.text = "출장가격 : " + item.price!
        cell.lblTime.text = "신청 시 \(hour)시간 \(minute)분 안에 도착가능"
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130.0
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let item = feedItem[indexPath.row] as! EngineerSelect
        
        
        let insertASEngineer = InsertASEngineer()
        let result: Bool = insertASEngineer.insertItems(cSeqno: USERDATA!.cSeqno, eSeqno: item.eSeqno!)
    
        if result {
            let resultAlert = UIAlertController(title: "완료", message: "입력이 되었습니다.", preferredStyle: UIAlertController.Style.alert)
            let onAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
            resultAlert.addAction(onAction)
            present(resultAlert, animated: true, completion: nil)
        } else {
            let resultAlert = UIAlertController(title: "실패", message: "에러가 발생 되었습니다.", preferredStyle: UIAlertController.Style.alert)
            let onAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
            resultAlert.addAction(onAction)
            present(resultAlert, animated: true, completion: nil)
        }
    }
}
