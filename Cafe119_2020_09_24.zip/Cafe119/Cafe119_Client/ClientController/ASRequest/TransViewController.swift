//
//  TransViewController.swift
//  Cafe119
//
//  Created by TJ on 2020/09/16.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit

var ENGINEERESEQNO: String!

class TransViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, MyClientReviewQueryModelProtocol, ASListSelectNetworkModelProtocol {
    
    @IBOutlet weak var MyClientReviewListView: UITableView!
    @IBOutlet var TransButton: UIButton!
    
    var feedItem: NSArray = NSArray()
    
    var ASList: ASListStruct?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        let queryModel = MyClientReviewQueryModel()
        // query 사용을 위한 delegate
        queryModel.delegate = self
        queryModel.downloadItems()
        
        MyClientReviewListView.delegate = self
        MyClientReviewListView.dataSource = self
        MyClientReviewListView.rowHeight = 200
        
        self.tabBarController?.navigationItem.setHidesBackButton(true, animated: true)
        
        // ASList 데이터 불러오기
        let ASListModel = ASListSelectNetworkModel()
        ASListModel.delegate = self
        ASListModel.downloadItems(urlPath: URLPATH + "ASList_Select.jsp?uSeqno=" + USERDATA!.cSeqno) // USERDATA!.cSeqno
    }
    
    // AS 신청
    func itemDownloaded(ASList: ASListStruct) {
        self.ASList = ASList
        
        ENGINEERESEQNO = ASList.Engineer_eSeqno
        
        switch ASList.aslStatus {
        case "1" :
            TransButton.titleLabel?.text = "AS기사님 선택"
        case "2":
            TransButton.titleLabel?.text = "기사님과 메시지하기"
        case "3" :
            TransButton.titleLabel?.text = "후기 작성"
        default:
            TransButton.titleLabel?.text = "AS 신청"
        }
    }
    
    // 우리 매장 후기
    func myClientReviewitemDownloaded(items: NSArray) {
        feedItem = items
        self.MyClientReviewListView.reloadData()
    }
    
    // MARK: - Table
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return feedItem.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ClientMyReviewCell", for: indexPath) as! ClientMyReviewTableViewCell
        // Configure the cell...
        let item: MyClientReviewDBModel = feedItem[indexPath.row] as! MyClientReviewDBModel // 배열로 되어있는 것을 class(DBModel) 타입으로 바꾼다.
        
        cell.lblName.text = (item.name!)
        cell.lblTelno.text = (item.telno!)
        cell.lblTrouble.text = (item.trouble!)
        cell.lblAddress.text = (item.address!)
        cell.lblScore.text = (item.score! + " / 5.0")
        cell.lblContent.text = (item.content!)
        
        return cell
    }
    
    // MARK: - Prepare
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "sgClientMyReviewDetail" {
            let cell = sender as! UITableViewCell
            let indexPath = self.MyClientReviewListView.indexPath(for: cell)
            print("indexpath : \(String(describing: indexPath))")
            
            let detailView = segue.destination as! CustomerASReviewDatailViewController
            
            let item: MyClientReviewDBModel = feedItem[(indexPath! as NSIndexPath).row] as! MyClientReviewDBModel
            let name = String(item.name!)
            let score = String(item.score!)
            let content = String(item.content!)
            
            detailView.receiveItems(name, score, content)
        }
    }
    
    // MARK: - ButtonEvent
    @IBAction func ASRequestButton(_ sender: UIButton) {
        switch ASList!.aslStatus {
        case "1" :
            NavigationMove(viewControllerName: "ASEngineerSelect")
        case "2":
            NavigationMove(viewControllerName: "ChatView")
        case "3" :
            NavigationMove(viewControllerName: "CustomerReview")
        default:
            NavigationMove(viewControllerName: "ASRequestView")
        }
    }
    
    func NavigationMove(viewControllerName: String) {
        let pushVC = self.storyboard?.instantiateViewController(withIdentifier: viewControllerName)
        self.navigationController?.pushViewController(pushVC!, animated: true)
    }
}
