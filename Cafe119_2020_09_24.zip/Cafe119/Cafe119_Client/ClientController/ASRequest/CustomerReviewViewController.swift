//
//  ViewController.swift
//  ReviewLast
//
//  Created by Leo_Jang on 2020/09/22.
//  Copyright © 2020 Leo_Jang. All rights reserved.
//

import UIKit

class CustomerReviewViewController: UIViewController{
    
    @IBOutlet weak var txtField: UITextView!
    @IBOutlet weak var btnDone: UIButton!
    @IBOutlet weak var floatRatingView: FloatRatingView!
    @IBOutlet weak var lblNumber: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        floatRatingView.backgroundColor = UIColor.clear
        
        floatRatingView.delegate = self
        floatRatingView.contentMode = UIView.ContentMode.scaleAspectFit
        floatRatingView.type = .halfRatings
        lblNumber.text = String(format: "%.1f", self.floatRatingView.rating)
    }
    
    // Button
    
    /*
     사용할 Insert SQL문
     insert into ClientReview (crMachine, crTrouble, crContent, crPart, crScore, crAddress, crDate, Engineer_eSeqno, Client_cSeqno)
     values ("커피머신", "고장내용", "후기내용", "부품", "평점", "매장주소", now(), 1, 1);
     */
    
    @IBAction func buttonInsert(_ sender: UIButton) {
        
        let erContent = txtField.text!
        let erScore = lblNumber.text!
        
        let Engineer_eSeqno = String(ENGINEERESEQNO)
        let Client_cSeqno = String(USERDATA!.cSeqno)
        
        if (erContent.isEmpty) {
            let emptyAlert = UIAlertController(title: "알림", message: "후기를 작성해주세요.", preferredStyle: UIAlertController.Style.alert)
            let okAction = UIAlertAction(title: "확인", style: UIAlertAction.Style.default, handler: nil)
            emptyAlert.addAction(okAction)
            present(emptyAlert,animated: true, completion: nil)
        }else{
            let insertModel = ClientReviewInsertModel()
            
            let result = insertModel.insertASR(erContent:erContent, erScore:erScore, Client_cSeqno:Client_cSeqno, Engineer_eSeqno:Engineer_eSeqno)
            if result { // 입력됐을 때
                let resultAlert = UIAlertController(title: "완료", message: "후기작성이 완료되었습니다. 감사합니다", preferredStyle: UIAlertController.Style.alert)
                let okAction = UIAlertAction(title: "확인", style: UIAlertAction.Style.default, handler: {Action in self.navigationController?.popViewController(animated: true)
                })
                resultAlert.addAction(okAction)
                present(resultAlert, animated: true, completion: nil)
            }else{ // 에러 발생시
                let resultAlert = UIAlertController(title: "진행중 에러발생", message: "후기작성을 다시해주세요.", preferredStyle: UIAlertController.Style.alert)
                let okAction = UIAlertAction(title: "확인", style: UIAlertAction.Style.default, handler: nil)
                resultAlert.addAction(okAction)
                present(resultAlert, animated: true, completion: nil)
            }
        }
    }
    
    // Rating
    
    
    
}

// FloatRatingViewDelegate
extension CustomerReviewViewController: FloatRatingViewDelegate {
    
    func floatRatingView(_ ratingView: FloatRatingView, didUpdate rating: Double) {
        lblNumber.text = String(format: "%.1f", self.floatRatingView.rating)
    }
}

