//
//  MainViewController.swift
//  MessengerTutorial
//
//  Created by Changsu Lee on 2020/09/16.
//  Copyright © 2020 Changsu Lee. All rights reserved.
//

import UIKit
import FirebaseStorage
import FirebaseDatabase

class ChatViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    @IBOutlet weak var chatList: UITableView!
    @IBOutlet weak var tfMessage: UITextField!

    var ref: DatabaseReference!
    
    let imagePicker = UIImagePickerController()
    
    var chatLists = [ChatModel]()
    
    var chatCell: ChatTableViewCell!
    var imageIndex = 0
    
    var USER_NAME = ""
    var RECEIVER_NAME = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        USER_NAME = USERDATA!.cSeqno
        RECEIVER_NAME = ENGINEERESEQNO
        
        ref = Database.database().reference()
        chatList.delegate = self
        chatList.dataSource = self
        
        imagePicker.delegate = self
        
        loadChatList()
        
        
        
    }
    
    // MARK: - Table
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return chatLists.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if chatLists[indexPath.row].sender == USER_NAME {
            if chatLists[indexPath.row].type == "text" {
                chatCell = tableView.dequeueReusableCell(withIdentifier: "myChatCell", for: indexPath) as? ChatTableViewCell
                chatCell.setChat(chatModel: chatLists[indexPath.row])
                chatCell.tvMessage.layer.cornerRadius = 10
                chatCell.tvMessage.textContainerInset = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
            } else {
                chatCell = tableView.dequeueReusableCell(withIdentifier: "myImageCell", for: indexPath) as? ChatTableViewCell
                chatCell.setImage(chatModel: chatLists[indexPath.row])
                chatCell.containerView.layer.cornerRadius = 10
                
                let singleTap = UITapGestureRecognizer(target: self, action: #selector(tapDetected))
                chatCell.ivImage.isUserInteractionEnabled = true
                chatCell.ivImage.addGestureRecognizer(singleTap)
                chatCell.ivImage.tag = indexPath.row
            }
        } else {
            if chatLists[indexPath.row].type == "text" {
                chatCell = tableView.dequeueReusableCell(withIdentifier: "otherChatCell", for: indexPath) as? ChatTableViewCell
                chatCell.setChat(chatModel: chatLists[indexPath.row])
                chatCell.tvMessage.layer.cornerRadius = 10
                chatCell.tvMessage.textContainerInset = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
            } else {
                chatCell = tableView.dequeueReusableCell(withIdentifier: "otherImageCell", for: indexPath) as? ChatTableViewCell
                chatCell.setImage(chatModel: chatLists[indexPath.row])
                chatCell.containerView.layer.cornerRadius = 10
                
                let singleTap = UITapGestureRecognizer(target: self, action: #selector(tapDetected))
                chatCell.ivImage.isUserInteractionEnabled = true
                chatCell.ivImage.addGestureRecognizer(singleTap)
                chatCell.ivImage.tag = indexPath.row
            }
        }
        
        return chatCell
    }
    
    @objc func tapDetected(tapGesture: UITapGestureRecognizer) {
        imageIndex = tapGesture.view!.tag
        performSegue(withIdentifier: "sgDetailImageView", sender: chatCell)
    }
    
    
    func loadChatList() {
        self.ref.child("chatting").child(USER_NAME).child(RECEIVER_NAME).queryOrdered(byChild: "time").observe(.value, with: { [self] (snapshot) in
            
            self.chatLists.removeAll()
            if let snapshot = snapshot.children.allObjects as? [DataSnapshot] {
                
                for snap in snapshot {
                    
                    if let postData = snap.value as? [String: AnyObject] {
                        
                        let sender = postData["from"] as! String
                        let message = postData["message"] as! String
                        let type = postData["type"] as! String
                        let isSeen = postData["isSeen"] as! Bool
                        
                        self.chatLists.append(ChatModel(sender: sender, receiver: self.RECEIVER_NAME, message: message, type: type, isSeen: isSeen))
                        
                    }
                    self.chatList.reloadData()
                    let indexPath = IndexPath(row: self.chatLists.count-1, section: 0)
                    self.chatList.scrollToRow(at: indexPath, at: .bottom, animated: true)
                    
                }
                
            }
            
        })
    }
    
    @IBAction func btnInputMessage(_ sender: UIButton) {
        
        let message = tfMessage.text!
        
        guard message.count > 0 else {
            return
        }
        
        // 값 쓰기
        let messageDictionary = ["from": USER_NAME, "to": RECEIVER_NAME, "isSeen": false, "message": message, "type": "text", "time": ServerValue.timestamp()] as [String : Any]
        self.ref.child("chatting").child(USER_NAME).child(RECEIVER_NAME).childByAutoId().setValue(messageDictionary)
        self.ref.child("chatting").child(RECEIVER_NAME).child(USER_NAME).childByAutoId().setValue(messageDictionary)
        
        tfMessage.text = ""
        
    }
    
    @IBAction func btnAddImage(_ sender: UIButton) {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if (info[UIImagePickerController.InfoKey.originalImage] as? UIImage) != nil {
            
            let imageUrl = info[UIImagePickerController.InfoKey.imageURL] as? URL
            
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyyMMddHHmmss"
            let currentTime = formatter.string(from: NSDate() as Date)
            let filename = "\(USER_NAME)_\(RECEIVER_NAME)_\(currentTime)"
            
            self.uploadImageToFireStorage(url: imageUrl!, filename: filename)
        }
        
        dismiss(animated: true, completion: nil)
    }
    
    func uploadImageToFireStorage(url: URL, filename: String) {
        // Local file you want to upload
        //let localFile = URL(string: "path/to/image")!
        let localFile = url

        // Create the file metadata
        let metadata = StorageMetadata()
        metadata.contentType = "image/jpeg"

        // Upload file and metadata to the object 'images/mountains.jpg'
        let storageRef = Storage.storage().reference().child("images/\(filename)")
        let uploadTask = storageRef.putFile(from: localFile, metadata: metadata)

        // Listen for state changes, errors, and completion of the upload.
        uploadTask.observe(.resume) { snapshot in
            // Upload resumed, also fires when the upload starts
        }

        uploadTask.observe(.pause) { snapshot in
            // Upload paused
        }

        uploadTask.observe(.progress) { snapshot in
            // Upload reported progress
            let percentComplete = 100.0 * Double(snapshot.progress!.completedUnitCount) / Double(snapshot.progress!.totalUnitCount)
            print(percentComplete)
        }

        uploadTask.observe(.success) { [self] snapshot in
            // Upload completed successfully
            // 값 쓰기
            let messageDictionary = ["from": self.USER_NAME, "to": self.RECEIVER_NAME, "isSeen": false, "message": filename, "type": "image", "time": ServerValue.timestamp()] as [String : Any]
            self.ref.child("chatting").child(self.USER_NAME).child(self.RECEIVER_NAME).childByAutoId().setValue(messageDictionary)
            self.ref.child("chatting").child(self.RECEIVER_NAME).child(self.USER_NAME).childByAutoId().setValue(messageDictionary)
        }

        uploadTask.observe(.failure) { snapshot in
            if let error = snapshot.error as NSError? {
                switch (StorageErrorCode(rawValue: error.code)!) {
                case .objectNotFound:
                    // File doesn't exist
                    print(error)
                    break
                case .unauthorized:
                    // User doesn't have permission to access file
                    print(error)
                    break
                case .cancelled:
                    // User canceled the upload
                    print(error)
                    break
                case .unknown:
                    // Unknown error occurred, inspect the server response
                    print(error)
                    break
                default:
                    // A separate error occurred. This is a good place to retry the upload.
                    print(error)
                    break
                }
            }
        }
        
    }
    
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "sgDetailImageView" {
            let detailView = segue.destination as! DetailImageViewViewController
            let item = chatLists[imageIndex]
            
            detailView.receivedMessage = item.message!
        }
    }
}
