//
//  ClientFindViewController.swift
//  Cafe119
//
//  Created by 문단비 on 2020/09/21.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit

class ClientFindViewController: UIViewController, ClientFindIdPwModelProtocol {
    
    @IBOutlet weak var tfFindIdEmail: UITextField!
    @IBOutlet weak var tfFindIdName: UITextField!
    @IBOutlet weak var tfFindPwId: UITextField!
    @IBOutlet weak var tfFindPwName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    // 아이디 찾기 버튼
    @IBAction func btnFindId(_ sender: UIButton) {
        let Name = tfFindIdName.text
        let Email = tfFindIdEmail.text
        
        
        let Find = ClientFindIdModel()
        Find.delegate = self
        Find.downloadItems(cName: Name!, cEmail: Email!)
        
    }
    
    func FindIditemDownloaded(name: String, email: String, id: String) {
        let name = tfFindIdName.text!
        let email = tfFindIdEmail.text!
        
        if name.isEmpty || email.isEmpty {
            myAlert(alertTitle: "실패", alertMessage: "이름, 이메일을 입력해주세요.", actionTitle: "OK", handler: nil)
        } else if name != tfFindIdName.text {
            myAlert(alertTitle: "실패", alertMessage: "등록되지않은 사용자입니다.", actionTitle: "OK", handler: nil)
        } else if email != tfFindIdEmail.text {
            myAlert(alertTitle: "실패", alertMessage: "이메일을 확인해주세요.", actionTitle: "OK", handler: nil)
        } else if id == "false" {
            myAlert(alertTitle: "실패", alertMessage: "이름, 이메일을 확인해주세요", actionTitle: "OK", handler: nil)
        } else {
            myAlert(alertTitle: "성공", alertMessage: "아이디는 \(id) 입니다.", actionTitle: "OK", handler: nil)
        }
    }
    
    @IBAction func btnFindPw(_ sender: UIButton) {
        let Name = tfFindPwName.text
        let Id = tfFindPwId.text
        
        
        let Find = ClientFindIdModel()
        Find.delegate = self
        Find.downloadItems2(cId: Id!, cName: Name!)
    }
    
    func FindPwitemDownloaded(name: String, id : String, pw: String) {
        let name = tfFindPwName.text!
        let id = tfFindPwId.text!
        
        if name.isEmpty || id.isEmpty {
            myAlert(alertTitle: "실패", alertMessage: "이름, 이메일을 입력해주세요.", actionTitle: "OK", handler: nil)
        } else if name != tfFindPwName.text {
            myAlert(alertTitle: "실패", alertMessage: "등록되지않은 사용자입니다.", actionTitle: "OK", handler: nil)
        } else if id != tfFindPwId.text {
            myAlert(alertTitle: "실패", alertMessage: "이메일을 확인해주세요.", actionTitle: "OK", handler: nil)
        } else if pw == "false" {
            myAlert(alertTitle: "실패", alertMessage: "아이디, 이름을 확인해주세요", actionTitle: "OK", handler: nil)
        } else {
            myAlert(alertTitle: "성공", alertMessage: "비밀번호는 \(pw) 입니다.", actionTitle: "OK", handler: nil)
        }
    }
    
    func myAlert(alertTitle: String, alertMessage: String, actionTitle: String, handler:((UIAlertAction) -> Void)?) {
        let resultAlert = UIAlertController(title: alertTitle, message: alertMessage, preferredStyle: UIAlertController.Style.alert)
        let onAction = UIAlertAction(title: actionTitle, style: UIAlertAction.Style.default, handler: handler)
        resultAlert.addAction(onAction)
        present(resultAlert, animated: true, completion: nil)
    }
}
