//
//  ChatTableViewCell.swift
//  MessengerTutorial
//
//  Created by Changsu Lee on 2020/09/17.
//  Copyright © 2020 Changsu Lee. All rights reserved.
//

import UIKit
import FirebaseStorage
import FirebaseUI

class ChatTableViewCell: UITableViewCell {

    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var tvMessage: UITextView!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var ivImage: UIImageView!
    
    func setChat(chatModel: ChatModel) {
        lblUserName.text = chatModel.sender
        tvMessage.text = chatModel.message
    }
    
    func setImage(chatModel: ChatModel) {
        lblUserName.text = chatModel.sender
        
        // Reference to an image file in Firebase Storage
        let storageRef = Storage.storage().reference()
        let reference = storageRef.child("images/\(chatModel.message!)")

        // UIImageView in your ViewController
        let imageView: UIImageView = ivImage

        // Placeholder image
        let placeholderImage = #imageLiteral(resourceName: "logo.png")

        // Load the image using SDWebImage
        imageView.sd_setImage(with: reference, placeholderImage: placeholderImage)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
