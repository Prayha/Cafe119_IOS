//
//  ShopReviewListTableViewCell.swift
//  Cafe119
//
//  Created by taeheum on 2020/09/18.
//  Copyright © 2020 tj. All rights reserved.
//

import UIKit

class ShopReviewListTableViewCell: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblTelno: UILabel!
    @IBOutlet weak var lblTrouble: UILabel!
    @IBOutlet weak var lblRegion: UILabel!
    @IBOutlet weak var lblContent: UILabel!
    @IBOutlet weak var viewCell: UIView!
    
}
