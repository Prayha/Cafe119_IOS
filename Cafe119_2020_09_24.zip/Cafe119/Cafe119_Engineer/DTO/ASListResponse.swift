//
//  ASListResponse.swift
//  Cafe119_Engineer
//
//  Created by TJ on 2020/09/21.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation

class ASListResponse: NSObject {
    
    var aslSeqno: Int?
    var shopName: String?
    var phone: String?
    var aslType: String?
    var shopAddress: String?
    var aslContent: String?
    
    override init() {
        
    }
    
    init(aslSeqno: Int, shopName: String, phone: String, aslType: String, shopAddress: String, aslContent: String) {
        self.aslSeqno = aslSeqno
        self.shopName = shopName
        self.phone = phone
        self.aslType = aslType
        self.shopAddress = shopAddress
        self.aslContent = aslContent
    }
}
