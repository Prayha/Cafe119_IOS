//
//  EngineerFindIdModel.swift
//  Cafe119
//
//  Created by 문단비 on 2020/09/21.
//  Copyright © 2020 tj. All rights reserved.
//

import Foundation

protocol EngineerFindIdPwModelProtocol: class {
    func EngineerFindIditemDownloaded(name: String, email: String, id: String)
    func EngineerFindPwitemDownloaded(name: String, id: String, pw: String)
}

class EngineerFindIdModel: NSObject {
    
    var delegate: EngineerFindIdPwModelProtocol!
    var urlPath = "http://localhost:8080/Cafe119/EngineerFindId_ios.jsp"
    
    func downloadItems(eName: String, eEmail: String){
        
        let urlAdd = "?eName=\(eName)&eEmail=\(eEmail)"
        
        urlPath += urlAdd
        
        // 한글 url encoding
        urlPath = urlPath.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        let url: URL = URL(string: urlPath)!
        print(url)
        let defaultSesstion = Foundation.URLSession(configuration: URLSessionConfiguration.default)
        let task = defaultSesstion.dataTask(with: url){(data, response, error) in
            if error != nil{
                print("Failed to select data")
            }else{
                print("Data is selected")
                self.parserJson(data!)
                
            }
        }
        task.resume()
        
    }
    
    func parserJson(_ data: Data) {
        //        var jsonResult = NSArray()
        var jsonResult = NSDictionary()
        
        do {
            jsonResult = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments) as! NSDictionary
        } catch let error as NSError {
            print(error)
        }
        
        let locations = NSMutableArray()
        
        let query = EngineerSignUpDBModel()
        var name: String = ""
        var email: String = ""
        var id: String = ""
        
        if let eId = jsonResult["eId"] as? String,
            let eName = jsonResult["eName"] as? String,
            let eEmail = jsonResult["eEmail"] as? String {
            
            query.eId = eId
            query.eName = eName
            query.eEmail = eEmail
            
            name = eName
            email = eEmail
            id = eId
        }
        
        locations.add(query)
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.delegate.EngineerFindIditemDownloaded(name: name, email: email, id: id)
        })
    }
    
    
    
    // -----------   비밀번호   ----------- \\

    var urlPath2 = "http://localhost:8080/Cafe119/EnginnerFindPassWord_ios.jsp"

    func EngineerdownloadItems2(eId: String, eName: String){

        let urlAdd = "?eId=\(eId)&eName=\(eName)"

        urlPath2 += urlAdd

        // 한글 url encoding
        urlPath2 = urlPath2.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        let url: URL = URL(string: urlPath2)!
        print(url)
        let defaultSesstion = Foundation.URLSession(configuration: URLSessionConfiguration.default)
        let task = defaultSesstion.dataTask(with: url){(data, response, error) in
            if error != nil{
                print("Failed to select data")
            }else{
                print("Data is selected")
                self.parserJson2(data!)

            }
        }
        task.resume()

    }

    func parserJson2(_ data: Data) {
        //        var jsonResult = NSArray()
        var jsonResult = NSDictionary()

        do {
            jsonResult = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments) as! NSDictionary
        } catch let error as NSError {
            print(error)
        }

        let locations = NSMutableArray()

        let query = EngineerSignUpDBModel()
        var ename: String = ""
        var eid: String = ""
        var epw: String = ""

        if let ePw = jsonResult["ePw"] as? String,
            let eName = jsonResult["eName"] as? String,
            let eId = jsonResult["eId"] as? String {

            query.eId = eId
            query.ePw = ePw
            query.eName = eName

            ename = eName
            eid = eId
            epw = ePw

        }

        locations.add(query)

        DispatchQueue.main.async(execute: {() -> Void in
            self.delegate.EngineerFindPwitemDownloaded(name: ename, id: eid, pw: epw)
        })
    }

    
    
    
}//--------------------------

