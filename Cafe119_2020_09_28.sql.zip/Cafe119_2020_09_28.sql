-- MySQL dump 10.13  Distrib 8.0.17, for macos10.14 (x86_64)
--
-- Host: 192.168.0.112    Database: Cafe119
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Administer`
--

DROP TABLE IF EXISTS `Administer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Administer` (
  `aSeqno` int(11) NOT NULL AUTO_INCREMENT,
  `aId` varchar(45) DEFAULT NULL,
  `aPw` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`aSeqno`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ASList`
--

DROP TABLE IF EXISTS `ASList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ASList` (
  `aslSeqno` int(11) NOT NULL AUTO_INCREMENT,
  `aslType` varchar(45) DEFAULT NULL,
  `aslContent` text,
  `aslImagePath` varchar(100) DEFAULT NULL,
  `aslDate` datetime DEFAULT NULL,
  `aslStatus` varchar(45) DEFAULT NULL,
  `Client_cSeqno` int(11) NOT NULL,
  `Engineer_eSeqno` int(11) DEFAULT '0',
  PRIMARY KEY (`aslSeqno`),
  KEY `fk_ASList_Client1_idx` (`Client_cSeqno`),
  CONSTRAINT `fk_ASList_Client1` FOREIGN KEY (`Client_cSeqno`) REFERENCES `client` (`cSeqno`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ASMatch`
--

DROP TABLE IF EXISTS `ASMatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ASMatch` (
  `Engineer_eSeqno` int(11) NOT NULL,
  `ASList_aslSeqno` int(11) NOT NULL,
  `Price` varchar(45) DEFAULT NULL,
  `ArrivalTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Engineer_eSeqno`,`ASList_aslSeqno`),
  KEY `fk_Engineer_has_ASList_ASList1_idx` (`ASList_aslSeqno`),
  KEY `fk_Engineer_has_ASList_Engineer1_idx` (`Engineer_eSeqno`),
  CONSTRAINT `fk_Engineer_has_ASList_ASList1` FOREIGN KEY (`ASList_aslSeqno`) REFERENCES `aslist` (`aslSeqno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_Engineer_has_ASList_Engineer1` FOREIGN KEY (`Engineer_eSeqno`) REFERENCES `engineer` (`eSeqno`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Client`
--

DROP TABLE IF EXISTS `Client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Client` (
  `cSeqno` int(11) NOT NULL AUTO_INCREMENT,
  `cId` varchar(45) DEFAULT NULL,
  `cPw` varchar(45) DEFAULT NULL,
  `cName` varchar(45) DEFAULT NULL,
  `cEmail` varchar(45) DEFAULT NULL,
  `cImage` varchar(80) DEFAULT NULL,
  `cTelno` varchar(45) DEFAULT NULL,
  `cBusinessNumber` varchar(45) DEFAULT NULL,
  `cDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `cRegion` varchar(45) DEFAULT NULL,
  `cLongitude` double DEFAULT NULL,
  `cLatitude` double DEFAULT NULL,
  PRIMARY KEY (`cSeqno`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ClientReview`
--

DROP TABLE IF EXISTS `ClientReview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClientReview` (
  `crSeqno` int(11) NOT NULL AUTO_INCREMENT,
  `crMachine` varchar(45) DEFAULT NULL,
  `crTrouble` varchar(45) DEFAULT NULL,
  `crContent` text,
  `crPart` varchar(45) DEFAULT NULL,
  `crScore` varchar(45) DEFAULT NULL,
  `crAddress` varchar(45) DEFAULT NULL,
  `crDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `Engineer_eSeqno` int(11) NOT NULL,
  `Client_cSeqno` int(11) NOT NULL,
  PRIMARY KEY (`crSeqno`),
  KEY `fk_ClientReview_Engineer_idx` (`Engineer_eSeqno`),
  KEY `fk_ClientReview_Client1_idx` (`Client_cSeqno`),
  CONSTRAINT `fk_ClientReview_Client1` FOREIGN KEY (`Client_cSeqno`) REFERENCES `client` (`cSeqno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ClientReview_Engineer` FOREIGN KEY (`Engineer_eSeqno`) REFERENCES `engineer` (`eSeqno`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Engineer`
--

DROP TABLE IF EXISTS `Engineer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Engineer` (
  `eSeqno` int(11) NOT NULL AUTO_INCREMENT,
  `eId` varchar(45) DEFAULT NULL,
  `ePw` varchar(45) DEFAULT NULL,
  `eName` varchar(45) DEFAULT NULL,
  `eEmail` varchar(45) DEFAULT NULL,
  `eImage` varchar(70) DEFAULT NULL,
  `eTelno` varchar(45) DEFAULT NULL,
  `eBusinessNumber` varchar(45) DEFAULT NULL,
  `eDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `eAddress` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`eSeqno`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EngineerReview`
--

DROP TABLE IF EXISTS `EngineerReview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EngineerReview` (
  `erSeqno` int(11) NOT NULL AUTO_INCREMENT,
  `erContent` text,
  `erScore` varchar(45) DEFAULT NULL,
  `Client_cSeqno` int(11) NOT NULL,
  `Engineer_eSeqno` int(11) NOT NULL,
  PRIMARY KEY (`erSeqno`),
  KEY `fk_EngineerReview_Client1_idx` (`Client_cSeqno`),
  KEY `fk_EngineerReview_Engineer1_idx` (`Engineer_eSeqno`),
  CONSTRAINT `fk_EngineerReview_Client1` FOREIGN KEY (`Client_cSeqno`) REFERENCES `client` (`cSeqno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_EngineerReview_Engineer1` FOREIGN KEY (`Engineer_eSeqno`) REFERENCES `engineer` (`eSeqno`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ImageFile`
--

DROP TABLE IF EXISTS `ImageFile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ImageFile` (
  `ifSeqno` int(11) NOT NULL AUTO_INCREMENT,
  `ifPath` varchar(60) DEFAULT NULL,
  `ClientReview_crSeqno` int(11) NOT NULL,
  PRIMARY KEY (`ifSeqno`),
  KEY `fk_ImageFile_ClientReview1_idx` (`ClientReview_crSeqno`),
  CONSTRAINT `fk_ImageFile_ClientReview1` FOREIGN KEY (`ClientReview_crSeqno`) REFERENCES `clientreview` (`crSeqno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-28 18:46:32
